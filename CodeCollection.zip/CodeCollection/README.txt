
R codes needed to reproduce figures and analysis in Kuismin & Sillanpaa, "Gap-com: General model selection method for sparse undirected networks with clustering structure" (to appear).