
# 08.06.2020

# Choose tuning parameter using gap-com statistic:

library(MASS)
library(huge)
library(igraph)
library(ggplot2)
library(foreach)
library(parallel)
library(doParallel)

source("Rfunctions/gap_com_parallel.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 13389

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 1000

g = 10 # Nmb of true clusters and/or hub nodes

HugeData = huge.generator(n=200, d=p, graph="hub", g=g) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

nrho = 50 # nmb of used tuning parameters

Cores = c(4, 6, 8, 10, 12)

CheckParallel = rep(0, length(Cores))

EllapsedTime = rep(0, 2*length(Cores))

##########################################################

# Compute the GGMs:

GSolutionPath = huge(HugeData$data, nlambda=nrho, method="ct")

Ind = seq(1, 9, by=2)

a = 1

for(i in Ind){
  
  registerDoParallel(cores = Cores[a])
  
  CheckParallel[a] = getDoParWorkers() # Just checking...
  
  # Gap-com, uniform sample
    
  EllapsedTime[i] = system.time(gap_com_parallel(GSolutionPath, Plot = F, B = 50,
                               method = "unif_sample"))[3]

  
  ##########################################################
  
  # Gap-com, Erdos-Renyi random graph sampling
  
  EllapsedTime[i + 1] = system.time(gap_com_parallel(GSolutionPath, Plot = F, B = 50,
                                                 method = "er_sample"))[3]
												 
  cat("\r", a)
  
  a = a + 1
  
}

Times = data.frame(Strategy = rep(c("Unif", "E-R"), times = 5), 
                   Threads = rep(Cores, each = 2),
                   Time = EllapsedTime)

write.table(Times, "ParallelTimes.txt", row.names = F, quote = F)

P = ggplot(Times, aes(x = Threads, y = Time, group = Strategy)) +
  geom_line(aes(linetype = Strategy), size = 1.5) +
  geom_point(size = 4) +
  labs(y = "Ellapsed time (seconds)") +
  theme(legend.position="bottom", axis.text=element_text(size=8),
        axis.title=element_text(size=10,face="bold"))

P

ggsave("Figure3.png", P, width=2.5, height = 2.5, dpi=600, units = "in")
