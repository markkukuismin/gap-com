
# 1.9.2021

# Summarize the results,

library(ggplot2)

Model = "scale-free" # hub, cluster or scale-free

path_to_file = paste0("Results/ct_", Model, "_n=100p=200_results.txt")

Data = read.table(path_to_file)

Data$clustering[Data$clustering == "WT"] = "Walktrap"

Data$clustering[Data$clustering == "FG"] = "Fast and greedy"

Data$clustering[Data$clustering == "PL"] = "Propagating labels"

P = ggplot(data = Data, aes(x = clustering, y = NMI)) +
  geom_boxplot() + 
  theme(legend.position = "bottom", axis.text = element_text(size = 8),
        axis.title=element_text(size = 10, face = "bold")) +
  ylab("NMI") +
  xlab("Community detection method")

BBName = paste("Boxplots/ct_", Model, "_NMI.png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")

##

P = ggplot(data = Data, aes(x = clustering, y = gapstatistic)) +
  geom_boxplot() + 
  theme(legend.position = "bottom", axis.text = element_text(size = 8),
        axis.title=element_text(size = 10, face = "bold")) +
  ylab("Gap-com statistic") +
  xlab("Community detection method")

BBName = paste("Boxplots/ct_", Model, "_gap-com.png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")


##

P = ggplot(data = Data, aes(x = clustering, y = lambda)) +
  geom_boxplot() + 
  theme(legend.position = "bottom", axis.text = element_text(size = 8),
        axis.title=element_text(size = 10, face = "bold")) +
  ylab("Tuning parameter value") +
  xlab("Community detection method")

BBName = paste("Boxplots/ct_", Model, "_lambda.png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")
