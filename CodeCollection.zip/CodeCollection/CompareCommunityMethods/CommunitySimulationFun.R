
# 31.8.2021

# Compare gap-com models when different community detection methods are used

# First, load the necessary R packages:

library(MASS)
library(huge)
library(igraph)
library(ggplot2)
library(foreach)
library(parallel)
library(doParallel)

# Run my own R function found in the folder "Rfunctions".

source("../Rfunctions/gap_com_parallel.R")

registerDoParallel(cores=2)

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 92478

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 200

Model = "scale-free" # scale-free, hub or cluster

NetMethod = "ct" # Method used to construct the sparse network. 

g = 10 # Nmb of true clusters and/or hubs in the network 

HugeData = huge.generator(n = 10, d = p, graph = Model, g = g) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

Sigma = HugeData$sigma

TrueA = as.matrix(HugeData$theta) # True GGM adjacency matrix

TrueG = graph.adjacency(TrueA, mode="undirected", diag=F)

TrueCommunities = walktrap.community(TrueG)

TrueNmbofClusters = length(unique(TrueCommunities$membership))

n = floor(p/2) # Sample size

nrho = 50 # nmb of used tuning parameters

##########################################################

Simrounds = 50

NMIResults_GapER_walktrap = rep(0, Simrounds)
NMIResults_GapER_PL = rep(0, Simrounds)
NMIResults_GapER_FG = rep(0, Simrounds)


lambda_GapER_walktrap = rep(0, Simrounds)
lambda_GapER_PL = rep(0, Simrounds)
lambda_GapER_FG = rep(0, Simrounds)


gap_com_GapER_walktrap = rep(0, Simrounds)
gap_com_GapER_PL = rep(0, Simrounds)
gap_com_GapER_FG = rep(0, Simrounds)

Nmb_of_clusters_GapER_walktrap = rep(0, Simrounds)
Nmb_of_clusters_GapER_PL = rep(0, Simrounds)
Nmb_of_clusters_GapER_FG = rep(0, Simrounds)

##########################################################

for(si in 1:Simrounds){
  
  Y = mvrnorm(n, rep(0, p), Sigma)
  
  # Compute nrho GGMs
  
  GSolutionPath = huge(Y, nlambda=nrho, method=NetMethod)
  
  ##########################################################
  
  # Gap-com, Erdos-Renyi random graph sampling using different community detection methods
  
  # 1) walktrap (default)
    
  GapER_walktrap = gap_com_parallel(GSolutionPath, Plot = F, B = 50, 
                                    method = "er_sample", clustering = "walktrap")
  
  # Construct the selected graphs,
  
  GapERIndex_walktrap = GapER_walktrap$opt.index
  
  GGapER_walktrap = graph.adjacency(GSolutionPath$path[[GapERIndex_walktrap]], mode="undirected", diag=F)
  
  GapERCommunities_walktrap = walktrap.community(GGapER_walktrap)
  
  ##########################################################
  
  # 2) propagating labels
  
  GapER_PL = gap_com_parallel(GSolutionPath, Plot = F, B = 50, 
                              method = "er_sample", clustering = "propagating_labels")
  
  
  # Construct the selected graphs,
  
  GapERIndex_PL = GapER_PL$opt.index
  
  GGapER_PL = graph.adjacency(GSolutionPath$path[[GapERIndex_PL]], mode="undirected", diag=F)
  
  GapERCommunities_PL = cluster_label_prop(GGapER_PL)
  
  
  ##########################################################
  
  # 3) Fast greedy

  GapER_FG = gap_com_parallel(GSolutionPath, Plot = F, B = 50, 
                              method = "er_sample", clustering = "fast_greedy")
  
  GapERIndex_FG = GapER_FG$opt.index
  
  GGapER_FG = graph.adjacency(GSolutionPath$path[[GapERIndex_FG]], mode="undirected", diag=F)
  
  GapERCommunities_FG = cluster_fast_greedy(GGapER_FG)
  
  ##########################################################
  ##########################################################
  
  # Collect the results. First, the NMI,

  NMIResults_GapER_walktrap[si] = igraph::compare(GapERCommunities_walktrap, TrueCommunities, method="nmi")
  NMIResults_GapER_PL[si] = igraph::compare(GapERCommunities_PL, TrueCommunities, method="nmi")
  NMIResults_GapER_FG[si] = igraph::compare(GapERCommunities_FG, TrueCommunities, method="nmi")
  
  #Pick the selected value of the tuning parameter...
  
  lambda_GapER_walktrap[si] = GapER_walktrap$opt.lambda
  lambda_GapER_PL[si] = GapER_PL$opt.lambda
  lambda_GapER_FG[si] = GapER_FG$opt.lambda
  
  # ... the gap-com statistic itself,
  
  gap_com_GapER_walktrap[si] = GapER_walktrap$GapStatistic[GapERIndex_walktrap]
  gap_com_GapER_PL[si] = GapER_PL$GapStatistic[GapERIndex_PL]
  gap_com_GapER_FG[si] = GapER_FG$GapStatistic[GapERIndex_FG]
  
  #... and the number of communities,
  
  Nmb_of_clusters_GapER_walktrap[si] = length(unique(GapERCommunities_walktrap$membership))
  Nmb_of_clusters_GapER_PL[si] = length(unique(GapERCommunities_PL$membership))
  Nmb_of_clusters_GapER_FG[si] = length(unique(GapERCommunities_FG$membership))
  
  cat("\r",si)
  
}


#####################################################

Results = data.frame(clustering = rep(c("WT", "PL", "FG"), each = Simrounds), 
                     NMI = c(NMIResults_GapER_walktrap, NMIResults_GapER_PL, NMIResults_GapER_FG),
                     lambda = c(lambda_GapER_walktrap, lambda_GapER_PL, lambda_GapER_FG),
                     gapstatistic = c(gap_com_GapER_walktrap, gap_com_GapER_PL, gap_com_GapER_FG),
                     nmb_of_clusters = c(Nmb_of_clusters_GapER_walktrap, Nmb_of_clusters_GapER_PL,
                                         Nmb_of_clusters_GapER_FG)
                     )

#####################################################

write.table(Results,
            paste("Results/", NetMethod, "_", Model, "_n=", n, "p=", p, "_results.txt", sep=""),
            quote = F)

boxplot(Results$gapstatistic ~ Results$clustering, names = c("Walktrap", "Prop. labels", "Fast Greedy"),
        ylab = "gap statistic", xlab = "clustering method")
