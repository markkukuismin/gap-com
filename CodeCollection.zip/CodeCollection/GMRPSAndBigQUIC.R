
# 03.06.2020

# Choose tuning parameter using gap-com statistic:

library(MASS)
library(huge)
library(BigQuic)
library(igraph)
library(ggplot2)
library(foreach)
library(parallel)
library(doParallel)
library(GMRPS)

registerDoParallel(cores=detectCores(all.tests=TRUE))


source("Rfunctions/SpSeFallPreMCC.txt")
source("Rfunctions/gap_com_BigQuic_parallel.R")
source("RFunctions/ModifyBigQUIC.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 9809

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 500

Model = "scale-free" # scale-free, hub or cluster

g = 10 # Nmb of true clusters and/or hub nodes

HugeData = huge.generator(n=10, d=p, graph=Model, g=g) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

Sigma = HugeData$sigma

TrueA = as.matrix(HugeData$theta) # True GGM adjacency matrix

TrueG = graph.adjacency(TrueA, mode="undirected", diag=F)

TrueCommunities = walktrap.community(TrueG)

n = 200 # Sample size

nlambda = 50 # nmb of used tuning parameters

lambda.min.ratio = 0.4 # Not sure if this is a valid parameter for BigQuic...

#########################################

Y = mvrnorm(n, rep(0, p), Sigma)

# Create a grid of log-spaced tuning parameter values

S = var(scale(Y))

lambda.max = max(max(S - diag(p)), -min(S - diag(p)))

lambda.min = lambda.min.ratio * lambda.max

lambda = exp(seq(log(lambda.max), log(lambda.min), length = nlambda))


BQSolPath = BigQuic(Y, outputFileName = "BigQuicMatrix", lambda = lambda,
                    numthreads = detectCores(all.tests=TRUE))

D = ModifyBigQUIC(BQSolPath)

AGNESResults = lambdaSelection(D, criterion = "AG")