
# 10.06.2020

library(ggplot2)
library(reshape2)

Method = "BQ" # ct or BQ

Model = "cluster" # cluster, hub or scale-free

Metric1 = "Classification"

Metric2 = "NMI"

p = 500

ModelAndMethod1 = paste(Metric1, "_" ,Method, "_", Model,"_n=200","p=",p , "_Class.res.txt", sep="")

ModelAndMethod2 = paste(Metric2, "_" ,Method, "_", Model,"_n=200","p=",p , "_Class.res.txt", sep="")

ResultsSenPreMCC = read.table(paste("Results/", ModelAndMethod1, sep=""))

ResultsClustering = read.table(paste("Results/", ModelAndMethod2, sep=""))

ResultsSenPreMCC = ResultsSenPreMCC[ResultsSenPreMCC$Method != "Oracle", ]

ResultsSenPreMCC$Method = factor(ResultsSenPreMCC$Method) # Otherwise factor level "Oracle" still there

ResultsSenPreMCC = ResultsSenPreMCC[ , c("Method", "Sen", "Pre", "MCC")]

##############################################################

# Rename values for article print

levels(ResultsSenPreMCC$Method)[levels(ResultsSenPreMCC$Method) == "Gap-com-unif"] = "gap-com (unif)"

levels(ResultsSenPreMCC$Method)[levels(ResultsSenPreMCC$Method) == "Gap-com-ER"] = "gap-com (E-R)"

levels(ResultsClustering$Method)[levels(ResultsClustering$Method) == "Gap-com-unif"] = "gap-com (unif)"

levels(ResultsClustering$Method)[levels(ResultsClustering$Method) == "Gap-com-ER"] = "gap-com (E-R)"

##############################################################

# First check if all standard errors are less than 0.027:

SECheck1 = matrix(0, 3, length(unique(ResultsSenPreMCC$Method)))

k = 1

for(i in 2:4){
  
  SECheck1[k, ] = tapply(ResultsSenPreMCC[ , i], ResultsSenPreMCC$Method, function(x) sd(x)/sqrt(length(x))) >= 0.027 
  
  k = k + 1
  
}

sum(SECheck1) # Should be zero

# The clustering results are easier to check:

tapply(ResultsClustering[ , 2], ResultsClustering$Method, function(x) sd(x)/sqrt(length(x))) >= 0.027

##############################################################

Sen = tapply(ResultsSenPreMCC[ , 2], ResultsSenPreMCC$Method, function(x) round(mean(x), digits = 2))[c(3, 2, 5, 4, 1)]

Pre = tapply(ResultsSenPreMCC[ , 3], ResultsSenPreMCC$Method, function(x) round(mean(x), digits = 2))[c(3, 2, 5, 4, 1)]

MCC = tapply(ResultsSenPreMCC[ , 4], ResultsSenPreMCC$Method, function(x) round(mean(x), digits = 2))[c(3, 2, 5, 4, 1)]

Clustering = tapply(ResultsClustering[ , 2], ResultsClustering$Method, function(x) round(mean(x), digits = 2))[c(3, 2, 5, 4, 1)]


Model

Method

cat(noquote(paste(names(Sen[1]), "&", Sen[1], "&", Pre[1], "&", MCC[1], "&", Clustering[1], "\\\\", "\n",
                  names(Sen[2]), "&", Sen[2], "&", Pre[2], "&", MCC[2], "&", Clustering[2], "\\\\", "\n",
                  names(Sen[3]), "&", Sen[3], "&", Pre[3], "&", MCC[3], "&", Clustering[3], "\\\\", "\n",
                  names(Sen[4]), "&", Sen[4], "&", Pre[4], "&", MCC[4], "&", Clustering[4], "\\\\", "\n",
                  names(Sen[5]), "&", Sen[5], "&", Pre[5], "&", MCC[5], "&", Clustering[5], "\\\\", "[3pt]", "\n")))

(Sen + Pre + MCC + Clustering)/4

##############################################################

Results = cbind(ResultsSenPreMCC, ResultsClustering[, 2])

colnames(Results) = c(colnames(ResultsSenPreMCC), colnames(ResultsClustering)[2])

Results = melt(Results)

colnames(Results) = c("Method", "Metric", "Value")

P = ggplot(Results, aes(x = Method, y=Value, fill=Metric)) +
  geom_boxplot() +
  theme(legend.position="bottom", axis.text=element_text(size=8),
        axis.title=element_text(size=10,face="bold"))

BBName = paste("Boxplots/", Method, "_", Model, ".png", sep="")

ggsave(BBName, P, width=4.75, height = 4, dpi=600, units = "in")
