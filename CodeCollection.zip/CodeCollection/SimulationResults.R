
# 30.06.2021

library(ggplot2)
library(reshape2)

Method = "BQ" # ct or BQ

Model = "random" # cluster, hub, scale-free or random

Metric1 = "Classification"

Metric2 = "NMI"

Metric3 = "nmb_of_clusters"

Metric4 = "lambda"

p = 500

ModelAndMethod1 = paste(Metric1, "_" ,Method, "_", Model,"_n=200","p=",p , "_Class.res.txt", sep="")

ModelAndMethod2 = paste(Metric2, "_" ,Method, "_", Model,"_n=200","p=",p , "_Class.res.txt", sep="")

ModelAndMethod3 = paste(Metric3, "_nonzero_" ,Method, "_", Model,"_n=200","p=",p , "_Class.res.txt", sep="")

ModelAndMethod4 = paste(Metric4, "_" ,Method, "_", Model,"_n=200","p=",p , "_Class.res.txt", sep="")

ResultsSenPreMCC = read.table(paste("Results/", ModelAndMethod1, sep = ""))

ResultsClustering = read.table(paste("Results/", ModelAndMethod2, sep = ""))

ResultsNmbOfClusters = read.table(paste("Results/", ModelAndMethod3, sep = ""))

Resultslambda = read.table(paste("Results/", ModelAndMethod4, sep = ""))

ResultsSenPreMCC = ResultsSenPreMCC[ResultsSenPreMCC$Method != "Oracle", ]

ResultsSenPreMCC$Method = factor(ResultsSenPreMCC$Method) # Otherwise factor level "Oracle" still there

ResultsSenPreMCC = ResultsSenPreMCC[ , c("Method", "Sen", "Pre", "MCC")]

##############################################################

# Rename values for article print

levels(ResultsSenPreMCC$Method)[levels(ResultsSenPreMCC$Method) == "Gap-com-permute"] = "gap-com (permute)"

levels(ResultsSenPreMCC$Method)[levels(ResultsSenPreMCC$Method) == "Gap-com-ER"] = "gap-com (E-R)"

##

levels(ResultsClustering$Method)[levels(ResultsClustering$Method) == "Gap-com-permute"] = "gap-com (permute)"

levels(ResultsClustering$Method)[levels(ResultsClustering$Method) == "Gap-com-ER"] = "gap-com (E-R)"

##

levels(ResultsNmbOfClusters$Method)[levels(ResultsNmbOfClusters$Method) == "Gap-com-permute"] = "gap-com (permute)"

levels(ResultsNmbOfClusters$Method)[levels(ResultsNmbOfClusters$Method) == "Gap-com-ER"] = "gap-com (E-R)"

##

levels(Resultslambda$Method)[levels(Resultslambda$Method) == "Gap-com-permute"] = "gap-com (permute)"

levels(Resultslambda$Method)[levels(Resultslambda$Method) == "Gap-com-ER"] = "gap-com (E-R)"

##############################################################

# First check if all standard errors are less than 0.027:

SECheck1 = matrix(0, 3, length(unique(ResultsSenPreMCC$Method)))

k = 1

for(i in 2:4){
  
  SECheck1[k, ] = tapply(ResultsSenPreMCC[ , i], ResultsSenPreMCC$Method, function(x) sd(x)/sqrt(length(x))) >= 0.027 
  
  k = k + 1
  
}

sum(SECheck1) # Should be zero

# The clustering results are easier to check:

tapply(ResultsClustering[ , 2], ResultsClustering$Method, function(x) sd(x)/sqrt(length(x))) >= 0.027

##############################################################

Sen = tapply(ResultsSenPreMCC[ , 2], ResultsSenPreMCC$Method, function(x) round(mean(x), digits = 2))[c(3, 2, 5, 4, 1)]

Pre = tapply(ResultsSenPreMCC[ , 3], ResultsSenPreMCC$Method, function(x) round(mean(x), digits = 2))[c(3, 2, 5, 4, 1)]

MCC = tapply(ResultsSenPreMCC[ , 4], ResultsSenPreMCC$Method, function(x) round(mean(x), digits = 2))[c(3, 2, 5, 4, 1)]

Clustering = tapply(ResultsClustering[ , 2], ResultsClustering$Method, function(x) round(mean(x), digits = 2))[c(3, 2, 5, 4, 1)]

NmbOfClusters = tapply(ResultsNmbOfClusters[ , 2], 
                       ResultsNmbOfClusters$Method, function(x) round(median(x), digits = 2))[c(3, 2, 5, 4, 1)]

NmbOfClustersIQR = tapply(ResultsNmbOfClusters[ , 2], 
                          ResultsNmbOfClusters$Method, function(x) round(IQR(x), digits = 2))[c(3, 2, 5, 4, 1)]

NmbOfClustersIQR

#lambda = tapply(Resultslambda[ , 2], Resultslambda$Method, function(x) round(mean(x), digits = 2))[c(3, 2, 5, 4, 1)]


Model

Method

cat(noquote(paste(names(Sen[1]), "&", Sen[1], "&", Pre[1], "&", MCC[1], "&", Clustering[1], "&", NmbOfClusters[1], "(", NmbOfClustersIQR[1], ")", "\\\\", "\n",
                  names(Sen[2]), "&", Sen[2], "&", Pre[2], "&", MCC[2], "&", Clustering[2], "&", NmbOfClusters[2], "(", NmbOfClustersIQR[2], ")", "\\\\", "\n",
                  names(Sen[3]), "&", Sen[3], "&", Pre[3], "&", MCC[3], "&", Clustering[3], "&", NmbOfClusters[3], "(", NmbOfClustersIQR[3], ")", "\\\\", "\n",
                  names(Sen[4]), "&", Sen[4], "&", Pre[4], "&", MCC[4], "&", Clustering[4], "&", NmbOfClusters[4], "(", NmbOfClustersIQR[4], ")", "\\\\", "\n",
                  names(Sen[5]), "&", Sen[5], "&", Pre[5], "&", MCC[5], "&", Clustering[5], "&", NmbOfClusters[5], "(", NmbOfClustersIQR[5], ")", "\\\\", "[3pt]", "\n")))

(Sen + Pre + MCC + Clustering)/4

if(Model == "scale-free") TrueNmbOfClusters = 40

if(Model == "random") TrueNmbOfClusters = 5

if(Model == "hub" | Model == "cluster") TrueNmbOfClusters = 10

NmbOfClustersMSE = tapply(ResultsNmbOfClusters[ , 2], 
                       ResultsNmbOfClusters$Method, function(x) round(mean((x - TrueNmbOfClusters)^2), digits = 2))[c(3, 2, 5, 4, 1)]

sqrt(NmbOfClustersMSE)

##############################################################

Results = cbind(ResultsSenPreMCC, ResultsClustering[, 2])

colnames(Results) = c(colnames(ResultsSenPreMCC), colnames(ResultsClustering)[2])

Results = melt(Results)

colnames(Results) = c("Method", "Metric", "Value")

P = ggplot(Results, aes(x = Method, y=Value, fill=Metric)) +
  geom_boxplot() +
  theme(legend.position="bottom", axis.text=element_text(size = 7),
        axis.title=element_text(size = 10, face = "bold"))

BBName = paste("Boxplots/", Method, "_", Model, ".png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")

##############################################################

# Nmb of clusters when isolated nodes (with degree zero) are removed

colnames(ResultsNmbOfClusters) = c("Method", "The number of clusters")

P = ggplot(ResultsNmbOfClusters, aes(x = Method, y = `The number of clusters`)) +
  geom_boxplot() +
  theme(legend.position="bottom", axis.text=element_text(size = 7),
        axis.title=element_text(size = 10, face = "bold")) +
  geom_hline(yintercept = TrueNmbOfClusters, linetype = "dashed", color = "red", size = 1.5)

BBName = paste("Boxplots/", Method, "_", Model, "_nmbofclusters.png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")

##############################################################

# What about the graph modularity?

Metric5 = "modularity"

ModelAndMethod3 = paste(Metric5, "_" ,Method, "_", Model,"_n=200","p=",p , "_Class.res.txt", sep="")

ModularityResults = read.table(paste("Results/", ModelAndMethod3, sep=""))

ModularityResults$Method[ModularityResults$Method == "Gap-com-permute"] = "gap-com (permute)"

ModularityResults$Method[ModularityResults$Method == "Gap-com-ER"] = "gap-com (E-R)"

P = ggplot(ModularityResults, aes(x = Method, y = modularity)) +
  geom_boxplot() +
  theme(legend.position = "bottom", axis.text = element_text(size = 8),
        axis.title=element_text(size = 10, face = "bold"))

BBName = paste("Boxplots/", Method, "_", Model, "_modularity.png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")

##############################################################

# Inspect the tuning parameters selected during the simulations,


lambdas = paste("lambda_" ,Method, "_", Model,"_n=200","p=",p , "_Class.res.txt", sep="")

Simulatedlambda = read.table(paste("Results/", lambdas, sep=""))

Simulatedlambda$Method[Simulatedlambda$Method == "Gap-com-permute"] = "gap-com (permute)"

Simulatedlambda$Method[Simulatedlambda$Method == "Gap-com-ER"] = "gap-com (E-R)"

Simulatedlambda$Method[Simulatedlambda$Method == "Gap-com-permute"] = "gap-com (permute)"

Simulatedlambda$Method[Simulatedlambda$Method == "Gap-com-ER"] = "gap-com (E-R)"

P = ggplot(Simulatedlambda, aes(x = Method, y = lambda)) +
  geom_boxplot() +
  theme(legend.position = "bottom", axis.text = element_text(size = 8),
        axis.title=element_text(size = 10, face = "bold")) +
  ylab("Tuning parameter values")

P

BBName = paste("Boxplots/", Method, "_", Model, "_lambda.png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")