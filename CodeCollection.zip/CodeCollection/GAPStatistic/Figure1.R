
# 11.02.2020

library(huge)
library(igraph)
library(ggplot2)
library(grid)
library(gridExtra)

source("Rfunctions/Gap_com.R")

# Generate a graphical model (clusterish or hubish structure)

p = 500

n = 1000

g = 100 # True nmb of clusters/hubs

###########################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 31258

set.seed(seed)

###########################

L = huge.generator(d=p, n=n, graph = "hub", g=g)

Y = L$data

###########################

# Compute the graph solution path:

nlambda = 50

HugeSolPath = huge(Y, method="ct", nlambda=nlambda)

# Find the optimal number of clusters and the optimal tuning/threshold parameter value

GapLambda = Gap_com(HugeSolPath, verbose = F, Plot = F, B = 100)

###########################

# Plot illustrative example:

GapData = data.frame(k = GapLambda$k, threshold = HugeSolPath$lambda, Expk = GapLambda$Expk, Gapcom = GapLambda$GapStatistic)
                       
Fig1 = ggplot(GapData, aes(x = threshold, y=k)) + 
  geom_line(aes(y = k), colour = "blue", linetype="solid") + 
  geom_point(aes(y = k), colour = "blue") +
  geom_line(aes(y = Expk), colour = "red", linetype="dashed") +
  geom_point(aes(y = Expk), colour = "red") +
  xlab("Hard threshold") +
  ylab("Estimated k and expected k") +
  theme(axis.text.x = element_text(size=7), axis.text.y = element_text(size=7))


Fig1 = Fig1 + labs(tag = "(a)") + geom_vline(xintercept = GapLambda$opt.lambda, linetype="dashed")

Fig2 = ggplot(GapData, aes(x = k, y=Gapcom)) + 
  geom_line(aes(y = Gapcom)) + 
  geom_point() +
  ylab("gap-com") + 
  theme(axis.text.x = element_text(size=7), axis.text.y = element_text(size=7))

Fig2 = Fig2 + labs(tag = "(b)") + geom_vline(xintercept = g, linetype="dashed")

GapLambda$k[GapLambda$opt.index]

g

grid.arrange(arrangeGrob(Fig1 + theme(legend.position="none"),
                         Fig2 + theme(legend.position="none"),
                         ncol = 2), nrow=1)


scale = 1

png("Figure1.png", width = 8*scale, height = 4*scale, res=300, units="in")

grid.arrange(arrangeGrob(Fig1 + theme(legend.position="none"),
                         Fig2 + theme(legend.position="none"),
                         ncol = 2), nrow=1)

dev.off()
