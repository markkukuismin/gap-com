
# 13.02.2020

# Check how different model selection criteria find TFs in SAureus network
# and are there similarities between pathogen module in the gene regulatory
# network and co-expression network. 

library(huge)
library(GMRPS)
library(ggplot2)

source("../Rfunctions/SpSeFallPreMCCVector.txt")
source("../Rfunctions/SpSeFallPreMCC.txt")
source("../Rfunctions/Gap_com.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 9809

set.seed(seed)

##########################################################

Data = read.table("net2_expression_data.tsv",header=T)

GeneNames = read.table("net2_gene_ids.tsv",skip=1,header=F)

TranscriptionFactors = read.table("net2_transcription_factors.tsv",header = F)

colnames(GeneNames) = c("ID","Names")
colnames(Data) = GeneNames[,2]

Data[1:3,1:5]
GeneNames[1:5,]

# Transcription factors are in order:

TranscriptionFactors =  GeneNames$Names[1:99]

dim(Data)

# From DREAM5 web page:

# "The expression data has been uniformly normalized for each compendium so 
#  that values are comparable across experiments."

Y = as.matrix(Data)

# However, many methods in the Marbach et al (2012) standardized gene profiles
# to zero mean and unit variance.

Y = huge.npn(Data)

p = ncol(Y)
n = nrow(Y)

hist(Y[,sample(1:p,1)],probability = T)

# What nodes are identified as hubs and how they match transcription factors?

# According to Marbach et al (2012) these are pathogens form a module of their own:

PathogenCluster = c("SAV2357","SAV0814","SAV2503","SAV2553","SAV0825","SAV1049","SAV0717",
                    "SAV0715","SAV0718","SAV0708","SAV0716","SAV0849","SAV0435","SAV1431",
                    "SAV0714","SAV0423","SAV0429","SAV2221","SAV1105","SAV0220","SAV1159",
                    "SAV0229","SAV2001","SAV2222","SAV0424" ,"SAV0426","SAV0749")

# These are Transcription factors in the pathogen cluster:

PathogenClusterTranscriptions = intersect(PathogenCluster, TranscriptionFactors)

# SAV2357 = tcaR

# SAV2503 = fibronectin-binding protein

# SAV0423 = Exotoxin 6

# SAV0423 = Exotoxin 7

# SAV0426 = Exotoxin 11

# SAV0429 = Exotoxin 14

#####################################################

# How we find:

# 1) Transciption factors. Are they identified as hubs?

# 2) Pathogen cluster

#####################################################

# Use simple correlation thresholding:

nlambda = 50

HugeSolPath = huge(Y, nlambda=nlambda, method="ct", lambda.min.ratio = 0.1)

#####################################################

# gap-com:

Gap = Gap_com(HugeSolPath, B = 100, verbose = T, Plot = T)

Gap$ValidGap

GapIndex = Gap$opt.index

AGap_com = as.matrix(HugeSolPath$path[[GapIndex]])

colnames(AGap_com) = GeneNames$Names

GapGraph_com = graph.adjacency(AGap_com, mode="undirected")

DegreeGap_com = colSums(AGap_com)

# 1) Are transcription factors identified as hubs?

# Examine, say, 100 hub nodes:

NmbSelected = 100

HubsGap_com = order(DegreeGap_com, decreasing = T)[1:NmbSelected]

HubsGap_com = GeneNames$Names[HubsGap_com]

length(intersect(HubsGap_com, TranscriptionFactors))

intersect(HubsGap_com, TranscriptionFactors)

as.character(HubsGap_com[1:10])

# 2) How is the cluster enrichted for pathogenic genes identified?

ClustersGap_com = walktrap.community(GapGraph_com)

length(table(membership(ClustersGap_com)))

#########

coords = layout_with_fr(GapGraph_com, grid="nogrid")

ESizes = rep(2, p)

V(GapGraph_com)$size=ESizes

NetColors = rep("white", p)

PathogenClusterInd = rep(NA, 27)

for(i in 1:27){
  
  PathogenClusterInd[i] = which(PathogenCluster[i] == GeneNames$Names) 
  
}

TranscriptionInd = 1:99

NetColors[PathogenClusterInd] = "lightgreen"
NetColors[TranscriptionInd] = "red"

plot(ClustersGap_com, GapGraph_com, mark.border=NA, mark.col = NA,layout=coords, vertex.label=NA,
     edge.arrow.size=.2, edge.color = "black",main="S.aureus network (gap-com)", col=NetColors)

#####################################################
#####################################################

# StARS

HugeSelectStARS = huge.select(HugeSolPath, criterion="stars", rep.num = 100, stars.thresh = 0.3)

AStARS = as.matrix(HugeSelectStARS$refit)

HugeSelectStARS$opt.index

StARSGraph = graph.adjacency(AStARS, mode="undirected")

DegreeStARS = colSums(AStARS)

# 1) Are transcription factors identified as hubs?

# Examine, say, 100 hub nodes:

HubsStARS = order(DegreeStARS, decreasing = T)[1:2]

HubsStARS = GeneNames$Names[HubsStARS]

length(intersect(HubsStARS, TranscriptionFactors))

intersect(HubsStARS, TranscriptionFactors)


# 2) How is the cluster enrichted for pathogenic genes identified?

ClustersStARS = walktrap.community(StARSGraph)

length(table(membership(ClustersStARS)))

#########

coords = layout_with_fr(StARSGraph, grid="nogrid")

V(StARSGraph)$size=ESizes

plot(ClustersStARS, StARSGraph, mark.border=NA, mark.col = NA,layout=coords, vertex.label=NA,
     edge.arrow.size=.2, edge.color = "black",main="S.aureus network (StARS)",col=NetColors)

#########################################################
#########################################################

# PC

d = lambdaSelection(HugeSolPath, criterion = "PC")

PCOptLambda = d$opt.lambda

PCIndex = which(HugeSolPath$lambda == PCOptLambda)

APC = as.matrix(HugeSolPath$path[[PCIndex]])

PCGraph = graph.adjacency(APC, mode="undirected")

DegreePC = colSums(APC)

# 1) Are transcription factors identified as hubs?

# Examine, say, 100 hub nodes:

HubsPC = order(DegreePC, decreasing = T)[1:NmbSelected]

HubsPC = GeneNames$Names[HubsPC]

length(intersect(HubsPC, TranscriptionFactors))

intersect(HubsPC, TranscriptionFactors)


# 2) How is the cluster enrichted for pathogenic genes identified?

ClustersPC = walktrap.community(PCGraph)

length(table(membership(ClustersPC)))


#########

coords = layout_with_fr(PCGraph, grid="nogrid")

V(PCGraph)$size=ESizes

plot(ClustersPC, PCGraph, mark.border=NA, mark.col = NA,layout=coords, vertex.label=NA,
     edge.arrow.size=.2, edge.color = "black", main="S.aureus network (PC)", col=NetColors)


#####################################################

# AGNES

d = lambdaSelection(HugeSolPath, criterion = "AG")

AGNESOptLambda = d$opt.lambda

AGNESIndex = which(HugeSolPath$lambda == AGNESOptLambda)

AAGNES = as.matrix(HugeSolPath$path[[AGNESIndex]])

AGNESGraph = graph.adjacency(AAGNES, mode="undirected")

DegreeAGNES = colSums(AAGNES)

# 1) Are transcription factors identified as hubs?

# Examine, say, 100 hub nodes:

HubsAGNES = order(DegreeAGNES, decreasing = T)[1:NmbSelected]

HubsAGNES = GeneNames$Names[HubsAGNES]

length(intersect(HubsAGNES, TranscriptionFactors))

intersect(HubsAGNES, TranscriptionFactors)


# 2) How is the cluster enrichted for pathogenic genes identified?

ClustersAGNES = walktrap.community(AGNESGraph)

length(table(membership(ClustersAGNES)))


#########

coords = layout_with_fr(AGNESGraph, grid="nogrid")

V(AGNESGraph)$size=ESizes

plot(ClustersAGNES, AGNESGraph, mark.border=NA, mark.col = NA,layout=coords, vertex.label=NA,
     edge.arrow.size=.2, edge.color = "black",main="S.aureus network (AGNES)",col=NetColors)

save.image("Saureus.RData")

#######################################
#######################################

#load("Saureus.RData")

# A better look at the pathogen genes:

# 2) How is the cluster enrichted for pathogenic genes identified?

table(ClustersGap_com$membership[PathogenClusterInd])

table(ClustersStARS$membership[PathogenClusterInd])

table(ClustersPC$membership[PathogenClusterInd])

table(ClustersAGNES$membership[PathogenClusterInd])


########################################

# Examine the pathogen community:

AGap_comPathogen = AGap_com[PathogenClusterInd, PathogenClusterInd]

GapGraph_comPathogen = graph.adjacency(AGap_comPathogen, mode="undirected")

ClustersGap_comPathogen = walktrap.community(GapGraph_comPathogen)

coordsGap_com = layout_with_fr(GapGraph_comPathogen, grid="nogrid",niter=10000)

table(ClustersGap_com$membership[PathogenClusterInd])

PathogenColsGap_com = rainbow(
  max(ClustersGap_com$membership[PathogenClusterInd]))[ClustersGap_com$membership[PathogenClusterInd]]

PathogenShapes = rep("circle", 27)

PathogenShapes[c(1, 4)] = "square" # Transcription factor nodes are squares

Gap_comPathodenDergree = colSums(AGap_comPathogen)
Gap_comPathodenNodeSize = 200*(Gap_comPathodenDergree/sum(Gap_comPathodenDergree))

V(GapGraph_comPathogen)$label.cex = 0.7
V(GapGraph_comPathogen)$size = Gap_comPathodenNodeSize

pdf("Gap_comPathogenGraph.pdf", onefile=T, paper='A4r')

plot(ClustersGap_comPathogen, GapGraph_comPathogen, mark.border=NA, mark.col = NA, layout=coordsGap_com, 
     vertex.label=PathogenCluster, edge.arrow.size=.2, edge.color = "gray",
     main="S.aureus pathogen network (Gap_com)", col=PathogenColsGap_com, vertex.shape=PathogenShapes)

dev.off()

########################################


AStARSPathogen = AStARS[PathogenClusterInd, PathogenClusterInd]

StARSGraphPathogen = graph.adjacency(AStARSPathogen,mode="undirected")

ClustersStARSPathogen = walktrap.community(StARSGraphPathogen)

coordsStARS = layout_with_fr(StARSGraphPathogen, grid="nogrid",niter=10000)

table(ClustersStARS$membership[PathogenClusterInd])
PathogenColsStARS = rainbow(
  max(ClustersStARS$membership[PathogenClusterInd]))[ClustersStARS$membership[PathogenClusterInd]]

pdf("StARSPathogenGraph.pdf", onefile=T, paper='A4r')

plot(ClustersStARSPathogen, StARSGraphPathogen, mark.border=NA, mark.col = NA,layout=coordsStARS, 
     vertex.label=PathogenCluster, edge.arrow.size=.2, edge.color = "gray",
     main="S.aureus pathogen network (StARS)",col=PathogenColsStARS, vertex.shape=PathogenShapes)

dev.off()

########################################

APCPathogen = APC[PathogenClusterInd, PathogenClusterInd]

PCGraphPathogen = graph.adjacency(APCPathogen,mode="undirected")

ClustersPCPathogen = walktrap.community(PCGraphPathogen)

coordsGGM = layout_with_fr(PCGraphPathogen, grid="nogrid",niter=10000)

table(ClustersPC$membership[PathogenClusterInd])
PathogenColsGGM = rainbow(
  max(ClustersPC$membership[PathogenClusterInd]))[ClustersPC$membership[PathogenClusterInd]]

pdf("PCPathogenGraph.pdf", onefile=T, paper='A4r')

plot(ClustersPCPathogen, PCGraphPathogen, mark.border=NA, mark.col = NA, layout=coordsGGM, 
     vertex.label=PathogenCluster, edge.arrow.size=.2, edge.color = "gray",
     main="S.auresu pathogen network (PC)", col=PathogenColsGGM, vertex.shape=PathogenShapes)

dev.off()

########################################

AAGNESPathogen = AAGNES[PathogenClusterInd, PathogenClusterInd]

AGNESGraphPathogen = graph.adjacency(AAGNESPathogen, mode="undirected")

ClustersAGNESPathogen = walktrap.community(AGNESGraphPathogen)

coordsT = layout_with_fr(AGNESGraphPathogen, grid="nogrid", niter=10000)

table(ClustersAGNES$membership[PathogenClusterInd])
PathogenColsT = rainbow(
  max(ClustersAGNES$membership[PathogenClusterInd]))[ClustersAGNES$membership[PathogenClusterInd]]

AGNESPathodenDergree = colSums(AAGNESPathogen)
AGNESPathodenNodeSize = 200*(AGNESPathodenDergree/sum(AGNESPathodenDergree))

V(AGNESGraphPathogen)$label.cex = 0.7
V(AGNESGraphPathogen)$size = AGNESPathodenNodeSize

pdf("AGNESPathogenGraph.pdf", onefile=T, paper='A4r')

plot(ClustersAGNESPathogen, AGNESGraphPathogen, mark.border=NA, mark.col = NA, layout=coordsT, 
     vertex.label=PathogenCluster, edge.arrow.size=.2, edge.color = "gray",
     main="S.aureus pathogen network (AGNES)", col=PathogenColsT, vertex.shape=PathogenShapes)

dev.off()

########################################

nmb = p*(p-1)/2

100*sum(AGap_com[upper.tri(AGap_com)])/nmb

100*sum(AStARS[upper.tri(AStARS)])/nmb

100*sum(APC[upper.tri(APC)])/nmb

100*sum(AAGNES[upper.tri(AAGNES)])/nmb

########################################

# Let's look at the hubs once moore:

as.character(HubsGap_com[1:100])

as.character(HubsStARS[1:2])

as.character(HubsPC[1:100])

as.character(HubsAGNES[1:100])

intersect(HubsGap_com[1:10], HubsStARS[1:2])

intersect(HubsGap_com[1:10], HubsPC[1:10])

intersect(HubsGap_com[1:10], HubsAGNES[1:10])

intersect(HubsPC[1:10], HubsAGNES[1:10])

which(GeneNames$Names == "SAV1900")


SAV1900NeighboursGap_com = which(AGap_com[ , which(GeneNames$Names == "SAV1900")] != 0)

SAV1900DataP = data.frame(ID=GeneNames$ID[SAV1900NeighboursGap_com],
                          Name=GeneNames$Names[SAV1900NeighboursGap_com])

write.table(SAV1900DataP, "SAV1900NeighborsGap_com.txt", row.names = F, quote=F)

##

membership(ClustersGap_com)[which(GeneNames$Names == "SAV1900")] # In which cluster the SAV1900 belongs to

SAV1900Cluster = which(membership(ClustersGap_com) == membership(ClustersGap_com)[which(GeneNames$Names == "SAV1900")])

SAV1900Adjacency = AGap_com[SAV1900Cluster, SAV1900Cluster]

SAV1900Graph = graph.adjacency(SAV1900Adjacency, mode="undirected")

SAV1900WTC = walktrap.community(SAV1900Graph)

coords = layout_with_fr(SAV1900Graph, grid="nogrid", niter=10000)

# This is also the largest cluster:

plot(SAV1900WTC, SAV1900Graph, mark.border=NA, mark.col = NA,layout=coords, 
     vertex.label=NA, edge.arrow.size=.2, edge.color = "black",
     main="Cluster of the highest hub node (gap-com)", col="white")

#################

# Compare the pathogen communites of gap-com and PC with each other:

Diagnostic(APCPathogen, AGap_comPathogen)

Diagnostic(AGap_comPathogen, AAGNESPathogen)

colnames(AGap_comPathogen) = GeneNames$Names[PathogenClusterInd]

colnames(AAGNESPathogen) = GeneNames$Names[PathogenClusterInd]

# Examine the neighborhood of SAV2357 (tcaR) and SAV2553 (tetracycline repressor) of
# gap-com and PC; StARS and PC do not have any neighbors with these TFs

colnames(AGap_comPathogen)[which(AGap_comPathogen[ ,"SAV2357"] != 0)]

colnames(AAGNESPathogen)[which(AAGNESPathogen[ ,"SAV2357"] != 0)]


colnames(AGap_comPathogen)[which(AGap_comPathogen[ ,"SAV2553"] != 0)]

colnames(AAGNESPathogen)[which(AAGNESPathogen[ ,"SAV2553"] != 0)]
