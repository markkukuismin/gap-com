
# 04.02.2020

# Choose tuning parameter using gap-com statistic:

library(MASS)
library(huge)
library(GMRPS)
library(igraph)

source("Rfunctions/SpSeFallPreMCC.txt")
source("Rfunctions/Gap_com.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 9809

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 1000 # 500 or 1000

Model = "scale-free" # scale-free, hub or cluster

NetMethod = "ct" # Method used to construct the sparse network. Either ct or mb

g = 10 # Nmb of true clusters and/or hub nodes

HugeData = huge.generator(n=10, d=p, graph=Model, g=g) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

Sigma = HugeData$sigma

TrueA = as.matrix(HugeData$theta) # True GGM adjacency matrix

n = 200 # Sample size

nrho = 50 # nmb of used tuning parameters

##########################################################

Simrounds = 50

BestSp = rep(0, Simrounds)
BestSen = rep(0, Simrounds) 
BestFall = rep(0, Simrounds)
BestPre = rep(0, Simrounds)
BestMCC = rep(0, Simrounds)

GapResults = matrix(0, Simrounds, 5)
colnames(GapResults) = c("Sp", "Sen", "Fall", "Pre", "MCC")

StARSResults = GapResults
PCResults = GapResults
AGNESResults = GapResults

BestResults = GapResults # For orcale method

##########################################################

for(si in 1:Simrounds){
  
  Y = mvrnorm(n, rep(0,p), Sigma)
  
  # Compute nrho GGMs
  
  HugeSolPath = huge(Y, nlambda=nrho, method=NetMethod)
  
  ##########################################################
  
  # Gap-com
  
  GapLambda = Gap_com(HugeSolPath, verbose = F, Plot = F, B = 50)
  
  GapIndex = GapLambda$opt.index
  
  # StARS
    
  HugeSelectStARS = huge.select(HugeSolPath, criterion="stars", rep.num = 50, stars.thresh = 0.05)
  
  ##########################################################
  
  # Path connectivity (PC):
  
  d = lambdaSelection(HugeSolPath, criterion = "PC")
  
  PCOptLambda = d$opt.lambda

  PCIndex = which(HugeSolPath$lambda == PCOptLambda)
  
  # AGlommerative NESted (AGNES):
  
  d = lambdaSelection(HugeSolPath, criterion = "AG")
  
  AGNESOptLambda = d$opt.lambda
  
  AGNESIndex = which(HugeSolPath$lambda == AGNESOptLambda)
  
  ##########################################################
  
  # What is the best the network method can do, condition to the solution path at hand?
  
  AllTheBest = matrix(0, nrho, 5)
  
  for(i in 1:nrho){
    
    AllTheBest[i, ] = unlist(Diagnostic(as.matrix(HugeSolPath$path[[i]]), TrueA))
    
  }
  
  BestSp[si] = max(AllTheBest[ ,1], na.rm = T) # Choose the graphical model that produces the best estimate of specificity
  BestSen[si] = max(AllTheBest[ ,2], na.rm = T) # Choose the graphical model that produces the best estimate of sensitivity
  BestFall[si] = min(AllTheBest[ ,3], na.rm = T) # Choose the graphical model that produces the best estimate of fall-out
  BestPre[si] = max(AllTheBest[ ,4], na.rm = T) # Choose the graphical model that produces the best estimate of precision
  BestMCC[si] = max(AllTheBest[ ,5], na.rm = T) # Choose the graphical model that produces the best estimate of MCC
  
  ##########################################################
  ##########################################################
  
  GapResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(HugeSolPath$path[[GapIndex]])))
  
  StARSResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(HugeSelectStARS$refit)))
  
  PCResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(HugeSolPath$path[[PCIndex]])))
  
  AGNESResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(HugeSolPath$path[[AGNESIndex]])))

  
  cat("\r",si)
  
}

BestResults[ , 1] = BestSp
BestResults[ , 2] = BestSen
BestResults[ , 3] = BestFall
BestResults[ , 4] = BestPre
BestResults[ , 5] = BestMCC

# Plot networks

huge.plot(HugeData$theta) # Truth
title("Ground truth")

huge.plot(HugeSolPath$path[[GapLambda$opt.index]])
title("Gap-com")

huge.plot(HugeSelectStARS$refit)
title("StARS")

huge.plot(HugeSolPath$path[[PCIndex]])# eBIC
title("PC")

huge.plot(HugeSolPath$path[[AGNESIndex]])
title("AGNES")

#####################################################

GapResults[is.na(GapResults)] = 0
StARSResults[is.na(StARSResults)] = 0
PCResults[is.na(PCResults)] = 0
AGNESResults[is.na(AGNESResults)] = 0

#####################################################

par(mfrow=c(2,3))

boxplot(GapResults, ylim=c(0,1))
title("Gap-com")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(StARSResults, ylim=c(0,1))
title("StARS")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(PCResults, ylim=c(0,1))
title("PC")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(AGNESResults, ylim=c(0,1))
title("AGNES")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

#####################################################

GapResults = data.frame("Method" = rep("Gap-com", Simrounds), GapResults)
StARSResults = data.frame("Method" = rep("StARS", Simrounds), StARSResults)
PCResults = data.frame("Method" = rep("PC", Simrounds), PCResults)
AGNESResults = data.frame("Method" = rep("AGNES", Simrounds), AGNESResults)
BestResults = data.frame("Method" = rep("Oracle", Simrounds), BestResults)

MergedResults = rbind(GapResults, StARSResults, PCResults, AGNESResults, BestResults)

write.table(MergedResults, paste("Results/", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""), quote = F)

