
# 28.1.2020

library(huge)
library(igraph)
library(ggplot2)

source("Rfunctions/Gap_com.R")
source("Rfunctions/SpSeFallPreMCC.txt")

# Generate a graphical model (clusterish or hubish structure)

p = 500

n = floor(p/2)

g = 5 # True nmb of clusters/hubs

###########################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 17978

set.seed(seed)

###########################

L = huge.generator(d=p, n=n, graph = "hub", g=g)

Y = L$data

###########################

# Compute the graph solution path:

nlambda = 50

HugeSolPath = huge(Y, method="ct", nlambda=nlambda)

# Find the optimal number of clusters and the optimal tuning/threshold parameter value

GapLambda = Gap_com(HugeSolPath, verbose = T, Plot = T, B = 50)

names(GapLambda)

# Check if max(Gap) fulfils the condition Gap[k] >= Gapk[k+1] - sk[k+1]

GapLambda$ValidGap

# Plot selected network:

huge.plot(HugeSolPath$path[[GapLambda$opt.index]])

title("GAP lambda")

# Compare the network with the true network:

TrueA = L$theta

GapLambda$opt.lambda

huge.plot(TrueA)

title("Ground truth")

# ... and with alternative graphical model selection criterion:

RIC = huge.select(HugeSolPath, criterion = "ric")

RIC$opt.lambda

huge.plot(RIC$refit)

title("RIC")

GapIndex = GapLambda$opt.index

GapLambda$k[GapIndex] # nmb of selected clusters

GRIC = graph.adjacency(as.matrix(RIC$refit), mode = "undirecte", diag = F)

d = cluster_walktrap(GRIC)

length(table(d$membership))

# Compute estimates of binary classification tests:

trueA = as.matrix(L$theta)

Diagnostic(trueA, as.matrix(HugeSolPath$path[[GapIndex]]))

Diagnostic(trueA, as.matrix(RIC$refit))

# How the hub nodes (only valid for the hub graph) are found?

order(colSums(trueA), decreasing=T)[1:g]

length(intersect(order(colSums(as.matrix(RIC$refit)), decreasing=T)[1:g], order(colSums(trueA), decreasing=T)[1:g]))

length(intersect(order(colSums(HugeSolPath$path[[GapIndex]]), decreasing=T)[1:g], order(colSums(trueA), decreasing=T)[1:g]))

       