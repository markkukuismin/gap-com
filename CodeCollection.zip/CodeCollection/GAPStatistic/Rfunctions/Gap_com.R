
Gap_com = function(HugeSolPath, B = 50, clustering="walktrap", w = NULL, steps = 4, Plot=F, verbose=F){
  
  lambda = HugeSolPath$lambda
  
  nlambda = length(lambda)
  
  k = rep(0, nlambda) # Nmb of clusters
  
  n = nrow(HugeSolPath$data)
  
  p = ncol(HugeSolPath$data)
  
  for(i in 1:nlambda){
    
    A = as.matrix(HugeSolPath$path[[i]])
    
    G = graph.adjacency(A, mode = "undirected", diag=F )
    
    if(clustering == "walktrap") d = cluster_walktrap(G, steps=steps, weights = w)
    
    if(clustering == "edge_betweenness") d = cluster_edge_betweenness(G, weights = w)
    
    if(clustering == "fast_greedy") d = cluster_fast_greedy(G, weights = w)
    
    k[i] = length(table(d$membership))
    
  }
  
  Expk = matrix(0, B, nlambda)
  
  for(b in 1:B){
    
    YNULL = apply(HugeSolPath$data, 2, function(x) runif(length(x), min(x), max(x)))
    
    HugeBootStrapSolPath = huge(YNULL, method = HugeSolPath$method, lambda=lambda, verbose = F)
    
    for(i in 1:nlambda){
      
      A = as.matrix(HugeBootStrapSolPath$path[[i]])
      
      G = graph.adjacency(A, mode = "undirected", diag=F )
      
      if(clustering == "walktrap") d = cluster_walktrap(G, steps=steps, weights = w)
      
      if(clustering == "edge_betweenness") d = cluster_edge_betweenness(G, weights = w)
      
      if(clustering == "fast_greedy") d = cluster_fast_greedy(G, weights = w)
      
      Expk[b, i] = length(table(d$membership))
      
    }
    
    if(verbose){
      
      Prog = paste(c("Subsampling progress ", floor(100 * b/B), "%"), collapse = "")
      cat(Prog, "\r")
      flush.console()
      
    }
    
  }
  
  sdExpk = apply(Expk, 2, sd)
  
  skk = sdExpk * sqrt(1 + 1/B)
  
  Expk = colMeans(Expk)
  
  Gap_lambda = Expk - k
  
  GapIndex = which.max(Gap_lambda)
  
  ind = nlambda:1
  
  ValGap = which.max(Gap_lambda) %in% ind[Gap_lambda[nlambda:2] >= Gap_lambda[(nlambda-1):1] - skk[(nlambda-1):1]]
  
  Results = list(opt.lambda = lambda[GapIndex], opt.index = GapIndex, GapStatistic = Gap_lambda, GapSE = skk, 
                 Expk = Expk, k = k, ValidGap = ValGap, algorithm = clustering)
  
  if(Plot == T){
    
    d = data.frame(x=lambda, y=Gap_lambda, SE=skk, lambda=lambda)
    
    Gp = qplot(data = d, x, y) + 
      geom_errorbar(aes(x = x, ymin = y - SE, ymax = y + SE), width = (max(lambda) - min(lambda))/20) +
      xlab(expression(lambda)) + 
      ylab(expression("abs(Gap_lambda)" %+-% "SE"))
   
    print(Gp)
     
  }
  
  return(Results)
  
}