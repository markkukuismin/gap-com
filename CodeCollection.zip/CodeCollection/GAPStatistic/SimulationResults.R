
# 10.02.2020

Method = "ct"

Model = "scale-free"

p = 1000

ModelAndMethod = paste(Method, "_", Model,"_n=200","p=",p , "_Class.res.txt", sep="")

Results = read.table(paste("Results/", ModelAndMethod, sep=""))

Results = Results[Results$Method != "Oracle", ]

Results$Method = factor(Results$Method) # Otherwise factor level "Oracle" still there

Results = Results[ , c("Method", "Sen", "Pre", "MCC")]

# First check if all standard errors are less than 0.01:

SECheck = matrix(0, 3, 4)

k = 1

for(i in 2:4){
  
  SECheck[k, ] = tapply(Results[ , i], Results$Method, function(x) sd(x)/sqrt(length(x))) >= 0.01 
  
  k = k + 1
  
}

sum(SECheck) # Should be zero

Sen = tapply(Results[ , 2], Results$Method, function(x) round(mean(x), digits = 2))[c(2, 4, 3, 1)]

Pre = tapply(Results[ , 3], Results$Method, function(x) round(mean(x), digits = 2))[c(2, 4, 3, 1)]
  
MCC = tapply(Results[ , 4], Results$Method, function(x) round(mean(x), digits = 2))[c(2, 4, 3, 1)]

Model

Method

cat(noquote(paste(names(Sen[1]), "&", Sen[1], "&", Pre[1], "&", MCC[1], "\\\\", "\n",
                  names(Sen[2]), "&", Sen[2], "&", Pre[2], "&", MCC[2], "\\\\", "\n",
                  names(Sen[3]), "&", Sen[3], "&", Pre[3], "&", MCC[3], "\\\\", "\n",
                  names(Sen[4]), "&", Sen[4], "&", Pre[4], "&", MCC[4], "\\\\", "\n")))
