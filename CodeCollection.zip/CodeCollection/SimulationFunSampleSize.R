
# 02.07.2021

# How the sample size affects to the estimated number of clusters?

# Before you start, set the working directory. In R Studio, this can be done
# from the toolbar: 

# "Session - Set Working Directory - To Source File Location"

# First, load the necessary R packages:

library(MASS)
library(huge)
library(GMRPS)
library(igraph)
library(ggplot2)
library(foreach)
library(parallel)
library(doParallel)

# To speed up computations, use parallel computing:

registerDoParallel(cores = detectCores(logical = F))

# Run my own R function found in the folder "Rfunctions".

source("Rfunctions/SpSeFallPreMCC.txt")
source("Rfunctions/gap_com_parallel.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 26561

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 200

N = seq(200, 1000, by = 200) # Sample size

Model = "other_random" # scale-free, hub, cluster, random (Erdos-Renyi) or other_random

NetMethod = "ct" # Cannot be changed!

g = 10 # Nmb of true clusters and/or hubs in the network 

HugeData = huge.generator(n = 10, d = p, graph = Model, g = g) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

if(Model == "random") HugeData = huge.generator(n = 10, d = p, graph = "random", prob = 0.263)

if(Model == "other_random") HugeData = huge.generator(n = 10, d = p, graph = "random")

Sigma = HugeData$sigma

TrueA = as.matrix(HugeData$theta) # True GGM adjacency matrix

TrueG = graph.adjacency(TrueA, mode="undirected", diag=F)

TrueCommunities = walktrap.community(TrueG)

TrueNmbofClusters = length(unique(TrueCommunities$membership))

nrho = 50 # nmb of used tuning parameters

##########################################################

Simrounds = 20

GapERResults = array(0, c(Simrounds, 5, length(N)))
colnames(GapERResults) = c("Sp", "Sen", "Fall", "Pre", "MCC")

ARIResultsGapER = matrix(0, Simrounds, length(N))

colnames(ARIResultsGapER) = N

NMIResultsGapER = ARIResultsGapER

lambda_GapER = ARIResultsGapER

Nmb_of_clusters_GapER = ARIResultsGapER

modularity_GapER = ARIResultsGapER

Nmb_of_clusters_nonzero_GapER = ARIResultsGapER

##########################################################

s = 1

for(n in N){
  
  for(si in 1:Simrounds){
    
    Y = mvrnorm(n, rep(0, p), Sigma)
    
    # Compute nrho GGMs
    
    GSolutionPath = huge(Y, nlambda=nrho, method=NetMethod)
    
    ##########################################################
    
    # Gap-com, Erdos-Renyi random graph sampling
    
    GapERLambda = gap_com_parallel(GSolutionPath, Plot = F, B = 50, 
                                   method = "er_sample")
    
    GapERIndex = GapERLambda$opt.index
    
    GGapER = graph.adjacency(GSolutionPath$path[[GapERIndex]], mode="undirected", diag=F)
    
    GapERCommunities = walktrap.community(GGapER)
    
    ##########################################################
    
    GapERResults[si,,s] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[GapERIndex]])))
    
    ##########################################################
    
    ARIResultsGapER[si, s] = igraph::compare(GapERCommunities, TrueCommunities, method="adjusted.rand")
    
    ##########################################################
    
    NMIResultsGapER[si, s] = igraph::compare(GapERCommunities, TrueCommunities, method="nmi")
    
    #Pick the selected value of the tuning parameter...
    
    lambda_GapER[si, s] = GapERLambda$opt.lambda
    
    #... and the number of communities,
    
    Nmb_of_clusters_GapER[si, s] = length(unique(GapERCommunities$membership))
    
    #... and modularity.
    
    modularity_GapER[si, s] = modularity(GapERCommunities)
    
    # Make graph where isolated nodes are removed,
      
    degrees = igraph::degree(GGapER)
      
    remove_nodes = which(degrees <= 1)
      
    GNoIsolated = igraph::delete_vertices(GGapER, v = remove_nodes)
      
    CommunitiesNoIsolated = igraph::walktrap.community(GNoIsolated)

    Nmb_of_clusters_nonzero_GapER[si, s] = length(unique(CommunitiesNoIsolated$membership))
    
    ##
    
    cat("\r", si)
    
  }
  
  s = s + 1
  
  cat("\r", n)
  
}

# Plot networks

huge.plot(HugeData$theta) # Truth
title("Ground truth")

huge.plot(GSolutionPath$path[[GapERLambda$opt.index]])
title("Gap-com, E-R sample")

#####################################################

GapERResults = data.frame("Method" = rep("Gap-com-ER", Simrounds), GapERResults)

#####################################################

GapERResultsARI = data.frame("Method" = rep("Gap-com-ER", Simrounds), "ARI" = ARIResultsGapER)

#####################################################

GapERResultsNMI = data.frame("Method" = rep("Gap-com-ER", Simrounds), "NMI" = NMIResultsGapER)

#####################################################

GapERResultslambda = data.frame("Method" = rep("Gap-com-ER", Simrounds), "lambda" = lambda_GapER)

#####################################################

GapERResults_nmb_of_clusters = data.frame("Method" = rep("Gap-com-ER", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_GapER)

#####################################################

GapERResults_modularity = data.frame("Method" = rep("Gap-com-ER", Simrounds), 
                                     "modularity" = modularity_GapER)

#####################################################

GapERResults_nmb_of_clusters_clean = data.frame("Method" = rep("Gap-com-ER", Simrounds), 
                                                "nmb.of.clusters.clean" = Nmb_of_clusters_nonzero_GapER)

#####################################################


write.table(GapERResults, 
            paste("Change_sample_size_results/Classification_", NetMethod, "_", Model, "_p=", p, "_Class.res.txt", sep=""), 
            quote = F)

write.table(GapERResultsARI, 
            paste("Change_sample_size_results/ARI_", NetMethod, "_", Model, "_p=", p, "_Class.res.txt", sep=""), 
            quote = F)

write.table(GapERResultsNMI,
            paste("Change_sample_size_results/NMI_", NetMethod, "_", Model, "_p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(GapERResultslambda, 
            paste("Change_sample_size_results/lambda_", NetMethod, "_", Model, "_p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(GapERResults_nmb_of_clusters, 
            paste("Change_sample_size_results/nmb_of_clusters_", NetMethod, "_", Model, "_p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(GapERResults_nmb_of_clusters_clean, 
            paste("Change_sample_size_results/nmb_of_clusters_nonzero_", NetMethod, "_", Model, "_p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(GapERResults_modularity, 
            paste("Change_sample_size_results/modularity_", NetMethod, "_", Model, "_p=", p, "_Class.res.txt", sep=""),
            quote = F)
