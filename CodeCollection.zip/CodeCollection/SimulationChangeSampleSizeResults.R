
# 24.8.2021

library(ggplot2)
library(reshape2)

Method = "ct" # only ct (hard thresholding)

Model = "other_random" # cluster, hub, scale-free, random or other_random

Metric1 = "Classification"

Metric2 = "NMI"

Metric3 = "nmb_of_clusters"

Metric4 = "lambda"

p = 200

ModelAndMethod1 = paste(Metric1, "_" ,Method, "_", Model,  "_p=", p , "_Class.res.txt", sep="")

ModelAndMethod2 = paste(Metric2, "_" ,Method, "_", Model,  "_p=", p , "_Class.res.txt", sep="")

ModelAndMethod3 = paste(Metric3, "_nonzero_" ,Method, "_", Model,  "_p=", p , "_Class.res.txt", sep="")

ModelAndMethod4 = paste(Metric4, "_" ,Method, "_", Model,  "_p=", p , "_Class.res.txt", sep="")

ResultsSenPreMCC = read.table(paste("Change_sample_size_results/", ModelAndMethod1, sep = ""))

ResultsClustering = read.table(paste("Change_sample_size_results/", ModelAndMethod2, sep = ""))

ResultsNmbOfClusters = read.table(paste("Change_sample_size_results/", ModelAndMethod3, sep = ""))

Resultslambda = read.table(paste("Change_sample_size_results/", ModelAndMethod4, sep = ""))

##############################################################

# Rename values for article print

levels(ResultsSenPreMCC$Method)[levels(ResultsSenPreMCC$Method) == "Gap-com-ER"] = "gap-com (E-R)"

##

levels(ResultsClustering$Method)[levels(ResultsClustering$Method) == "Gap-com-ER"] = "gap-com (E-R)"

##

levels(ResultsNmbOfClusters$Method)[levels(ResultsNmbOfClusters$Method) == "Gap-com-ER"] = "gap-com (E-R)"

##

levels(Resultslambda$Method)[levels(Resultslambda$Method) == "Gap-com-ER"] = "gap-com (E-R)"

##############################################################

if(Model == "scale-free") TrueNmbOfClusters = 19

if(Model == "random") TrueNmbOfClusters = 5

if(Model == "other_random") TrueNmbOfClusters = 49

if(Model == "hub" | Model == "cluster") TrueNmbOfClusters = 10

##############################################################

# Draw a boxplot of the number of detected clusters when p = 200 and the sample size increases,

colnames(ResultsNmbOfClusters)[-1] = c("200", "400", "600", "800", "1000")

ResultsNmbOfClusters = reshape2::melt(ResultsNmbOfClusters)

colnames(ResultsNmbOfClusters)[-1] = c("Sample size", "The number of clusters")

P = ggplot(ResultsNmbOfClusters, aes(x = `Sample size`, y = `The number of clusters`)) +
  geom_boxplot() +
  theme(legend.position="bottom", axis.text=element_text(size = 7),
        axis.title=element_text(size = 10, face = "bold"),
        plot.title = element_text(hjust = 0.5)) +
  ggtitle("Gap-com, E-R strategy") +
  geom_hline(yintercept = TrueNmbOfClusters, linetype = "dashed", color = "red", size = 1.5)

P

BBName = paste("Change_sample_size_results/Boxplots/", Method, "_", Model, "_nmbofclusters.png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")

##############################################################

# Draw a boxplot of the NMI results: 0 = no mutual information, 1 = perfect correlation,

colnames(ResultsClustering)[-1] = c("200", "400", "600", "800", "1000")

ResultsClustering = reshape2::melt(ResultsClustering)

colnames(ResultsClustering)[-1] = c("Sample size", "NMI")

P = ggplot(ResultsClustering, aes(x = `Sample size`, y = NMI)) +
  geom_boxplot() +
  theme(legend.position="bottom", axis.text=element_text(size = 7),
        axis.title=element_text(size = 10, face = "bold"),
        plot.title = element_text(hjust = 0.5)) +
  ggtitle("Gap-com, E-R strategy") 

P

BBName = paste("Change_sample_size_results/Boxplots/", Method, "_", Model, "_NMI.png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")

##############################################################

# Draw a boxplot of the binary classification results,

ResultsSenPreMCC = reshape2::melt(ResultsSenPreMCC)

ResultsSenPreMCC$`Sample size` = rep(c("200", "400", "600", "800", "1000"), each=100)

ResultsSenPreMCC$`Sample size` = factor(ResultsSenPreMCC$`Sample size`, 
                                        levels = c("200", "400", "600", "800", "1000"))

colnames(ResultsSenPreMCC)[2] = "Metric"

ResultsSenPreMCC$Metric = gsub("\\..*", "", ResultsSenPreMCC$Metric)

P = ggplot(ResultsSenPreMCC, aes(x = `Sample size`, y = value, fill = Metric)) +
  geom_boxplot() +
  theme(legend.position="bottom", axis.text=element_text(size = 7),
        axis.title=element_text(size = 10, face = "bold"),
        plot.title = element_text(hjust = 0.5)) +
  ggtitle("Gap-com, E-R strategy") 

P

BBName = paste("Change_sample_size_results/Boxplots/", Method, "_", Model, ".png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")
