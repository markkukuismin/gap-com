#' Gap-com statistic BigQuic
#'
#' Computes the gap-com statistic which can be applied for regularization selection of sparse undirected network estimates with clustering structure. This version is compatible with huge package (tested on v 1.2.7).
#' @param BQSolPath Solution path computed with huge.
#' @param B Number of reference data sets generated. Default is 50.
#' @param clustering Community detection method. Can be either "walktrap" (default), "propagating_labels" or "fast_greedy".
#' @param w Edge weights. Default NULL.
#' @param steps The length of the random walks to perform. Default 4.
#' @param Plot Should the gap-com statistic be plotted. Default FALSE.
#' @param method Determine the number of expected clusters using (i) permuted data ("permute_sample") (ii) reference graph ("er_sample", default).
#' @param verbose Print the sampling progress. Default FALSE.
#' @return A list containing the following components:
#' \itemize{
#' \item opt.lambda - The largest regularization parameter value which maximizes gap-com.
#' \item opt.index - The index of the regularization parameter value which maximizes gap-com.
#' \item GapStatistic - gap-com statistic.
#' \item GapSE - Standard error of gap-com.
#' \item Expk - Expected number of network communities (clusters) under the reference distribution which is the permuted data set.
#' \item k - Estimated number of network communities.
#' \item ValidGap - Check if max(gap_com) fulfils the condition gap_com[k] >= gap_com[k+1] - GapSE[k+1]
#' \item algorithm - The community detection method used.
#' }
#' 
#' @keywords cluster gap huge network model selection sparse scio
#' @export
#' @examples
#' library(BigQuic)
#' library(huge)
#' library(igraph)
#' library(ggplot2)
#' 
#' set.seed(46023979)
#' 
#' L = huge.generator(d=100, n=120, graph = "hub", g=5)
#' 
#' Y = L$data
#' 
#' nlambda = 50
#' 
#' S = var(scale(Y))
#'
#' lambda.max = max(max(S - diag(p)), -min(S - diag(p)))
#'
#' lambda.min = lambda.min.ratio * lambda.max
#'
#' lambda = exp(seq(log(lambda.max), log(lambda.min), length = nrho))
#' 
#' BQSolutionPath = BigQuic(Y, lambda = lambda)
#' 
#' gapLambda = gap_com_BQ(BQSolutionPath, verbose = T, Plot = T, B = 50)
#' 
#' huge.plot(L$theta)
#' 
#' title("Ground truth")
#' 
#' huge.plot(HugeSolutionPath$path[[gapLambda$opt.index]])
#' 
#' title("gap-com")
#'
#' @export
#'
#' @author Markku Kuismin, Mikko J. Sillanpaa
#'
#' @references Kuismin and Sillanpaa (2020) Gap-com: General model selection method for sparse undirected networks with clustering structure

gap_com_BQ = function(BQSolPath, B = 50, clustering="walktrap", w = NULL, steps = 4, Plot=F, method="er_sample", verbose=F){
  
  lambda = BQSolPath$lambda
  
  nlambda = length(lambda)
  
  k = rep(0, nlambda) # Nmb of clusters
  
  n = nrow(BQSolPath$X)
  
  p = ncol(BQSolPath$X)
  
  if(clustering == "walktrap") f = function(G) cluster_walktrap(G, steps=steps, weights = w)
  
  if(clustering == "propagating_labels") f = function(G) cluster_label_prop(G, weights = w)
  
  if(clustering == "fast_greedy") f = function(G) cluster_fast_greedy(G, weights = w)
  
  for(i in 1:nlambda){
    
    A = as.matrix(BQSolPath$precision_matrices[[i]])
    
    A[A != 0] = 1
    
    diag(A) = 0
    
    G = graph.adjacency(A, mode = "undirected", diag=F )
    
    d = f(G)
    
    k[i] = length(table(d$membership))
    
  }
  
  Expk = matrix(0, B, nlambda)
  
  for(b in 1:B){
    
    if(method == "permute_sample"){
      
      YNULL = apply(BQSolPath$X, 2, function(x) x[sample(1:length(x))])
      
      BQPermuteSolPath = BigQuic(YNULL, lambda = lambda, numthreads = 6, use_ram = T)
      
      for(i in 1:nlambda){
        
        A = as.matrix(BQPermuteSolPath$precision_matrices[[i]])
        
        A[A != 0] = 1
        
        diag(A) = 0
        
        G = graph.adjacency(A, mode = "undirected", diag=F )
        
        d = f(G)
        
        Expk[b, i] = length(table(d$membership))
        
      }
      
    }
    
    if(method == "er_sample"){
      
      if(b == 1){
        
        YNULL = apply(BQSolPath$X, 2, function(x) x[sample(1:length(x))])
        
        DummySolPath = BigQuic(YNULL, lambda = lambda, numthreads = 6, use_ram = T)
  
        DummySparsity = BQSparsity(DummySolPath)
        
        remove(list=c("YNULL", "DummySolPath"))
        
      }
      
      for(i in 1:nlambda){
        
        G = erdos.renyi.game(p, DummySparsity[i] , type="gnp")
        
        if(clustering == "walktrap") d = cluster_walktrap(G, steps=steps, weights = w)
        
        if(clustering == "propagating_labels") d = cluster_label_prop(G, weights = w)
        
        if(clustering == "fast_greedy") d = cluster_fast_greedy(G, weights = w)
        
        Expk[b, i] = length(table(d$membership))
        
      }
      
    }
    
    if(verbose){
      
      Prog = paste(c("Subsampling progress ", floor(100 * b/B), "%"), collapse = "")
      cat(Prog, "\r")
      flush.console()
      
    }
    
  }
  
  sdExpk = apply(Expk, 2, sd)
  
  skk = sdExpk * sqrt(1 + 1/B)
  
  Expk = colMeans(Expk)
  
  Gap_lambda = Expk - k
  
  GapIndex = which.max(Gap_lambda)
  
  ind = nlambda:1
  
  ValGap = which.max(Gap_lambda) %in% ind[Gap_lambda[nlambda:2] >= Gap_lambda[(nlambda-1):1] - skk[(nlambda-1):1]]
  
  Results = list(opt.lambda = lambda[GapIndex], opt.index = GapIndex, GapStatistic = Gap_lambda, GapSE = skk, 
                 Expk = Expk, k = k, ValidGap = ValGap, algorithm = clustering)
  
  if(Plot == T){
    
    d = data.frame(x=lambda, y=Gap_lambda, SE=skk, lambda=lambda)
    
    Gp = qplot(data = d, x, y) + 
      geom_errorbar(aes(x = x, ymin = y - SE, ymax = y + SE), width = (max(lambda) - min(lambda))/20) +
      xlab(expression(lambda)) + 
      ylab(expression("Gap_lambda" %+-% "SE")) +
      ggtitle(method) +
      theme(plot.title = element_text(hjust = 0.5))
    
    print(Gp)
    
  }
  
  return(Results)
  
}