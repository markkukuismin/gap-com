
BQSparsity = function(BQSolPath){
  
  nlambda = length(BQSolPath$lambda)
  
  sparsity = numeric()
  
  for(i in 1:nlambda){
    
    Theta = as.matrix(BQSolPath$precision_matrices[[i]])
    
    sparsity[i] = (sum(Theta != 0) - ncol(Theta))/((ncol(Theta)^2 - ncol(Theta)))
    
  }
  
  return(sparsity)
  
}