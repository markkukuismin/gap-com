
FUN_MI = function(data, nlambda){
  
  M = infotheo::mutinformation(infotheo::discretize(data), method = "emp")
  
  diag(M) = 0
  
  p = ncol(M)
  
  M = abs(M)
  
  M.rank = order(M, decreasing = TRUE)
  
  lambda.min.ratio = 0.05
  
  density.max = lambda.min.ratio*p*(p - 1)/2
  
  density.min = 1
  
  density.all = ceiling(seq(density.min, density.max, length = nlambda))*2
  
  lambda = M[M.rank[density.all]]
  
  path = list()
  
  A = Matrix::Matrix(0, p, p, sparse = T)
  
  for(i in 1:nlambda){
  
    A2 = A
   
    A2[M > lambda[i]] = 1
   
    path[[i]] = A2
   
  }
  
  return(list(lambda = lambda, data = data, path = path))
  
}