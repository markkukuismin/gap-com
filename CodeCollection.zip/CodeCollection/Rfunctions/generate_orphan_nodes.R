
generate_orphan_nodes = function(G, Model, v = 0.3, u = 0.1, orphans_percentage = 0.25){
  
  A = igraph::get.adjacency(G)
  
  A = as.matrix(A)
  
  nmb_of_neigh = degree(G)
  
  if(Model != "hub") nonzero = which(nmb_of_neigh != 0)
  
  if(Model == "hub") nonzero = which(nmb_of_neigh != 1)
  
  orphans = sample(nonzero, floor(orphans_percentage*length(nonzero)))
  
  A2 = A
  
  A2[orphans, ] = 0
  
  A2[, orphans] = 0
  
  G2 = igraph::graph.adjacency(A2, mode = "undirected")
  
  Theta = A2*v
  
  diag(Theta) = abs(min(eigen(Theta)$values)) + 0.1 + u
  
  Sigma = cov2cor(solve(Theta))
  
  G_list = list(G_orphans = G2, Sigma = Sigma, A = A2, Theta = Theta)
  
  return(G_list)
  
}