
# 02.09.2021

# Choose tuning parameter using gap-com statistic and evaluate the performance.

# Unlike in the other simulation study, now we evaluate the performance of the methods
# when there are "orphan nodes" (zero degree nodes) in the true graphical model

# Before you start, set the working directory. In R Studio, this can be done
# from the toolbar: 

# "Session - Set Working Directory - To Source File Location"

# First, load the necessary R packages:

library(MASS)
library(huge)
library(GMRPS)
library(igraph)
library(ggplot2)
library(foreach)
library(parallel)
library(doParallel)

# To speed up computations, use parallel computing:

#registerDoParallel(cores=detectCores(all.tests=TRUE))

registerDoParallel(cores = 2)

# Run my own R function found in the folder "Rfunctions".

source("../Rfunctions/SpSeFallPreMCC.txt")
source("../Rfunctions/gap_com_parallel.R")
source("../Rfunctions/generate_orphan_nodes.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 92588

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 500 # Here we use just 500

Model = "random" # scale-free, hub, cluster or random

NetMethod = "ct" # Here we use only ct (correlation thresholding)

g = 10 # Nmb of true clusters and/or hubs in the network 

HugeData = huge::huge.generator(n = 10, d = p, graph = Model, g = g) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

if(Model == "random") HugeData = huge.generator(n = 10, d = p, graph = Model, prob = 0.263)

TrueA = as.matrix(HugeData$theta) # True GGM adjacency matrix

TrueG = igraph::graph.adjacency(TrueA, mode="undirected", diag=F)

Orphan_simulation = generate_orphan_nodes(G = TrueG, Model = Model)

# Update the true adjacency matrix, covariance matrix and the corresponding graphical model, when
# the graph contains so called orphan nodes (zero degree nodes),

TrueA = Orphan_simulation$A

Sigma = Orphan_simulation$Sigma

TrueG = Orphan_simulation$G_orphans

# Now we can continue,

TrueCommunities = igraph::walktrap.community(TrueG)

TrueNmbofClusters = length(unique(TrueCommunities$membership))

n = 200 # Sample size

nrho = 50 # nmb of used tuning parameters

##########################################################

Simrounds = 50

BestSp = rep(0, Simrounds)
BestSen = rep(0, Simrounds) 
BestFall = rep(0, Simrounds)
BestPre = rep(0, Simrounds)
BestMCC = rep(0, Simrounds)

GapPermuteResults = matrix(0, Simrounds, 5)
colnames(GapPermuteResults) = c("Sp", "Sen", "Fall", "Pre", "MCC")

GapERResults = GapPermuteResults
StARSResults = GapPermuteResults
PCResults = GapPermuteResults
AGNESResults = GapPermuteResults

BestResults = GapPermuteResults # For oracle method

ARIResultsGapPermute = rep(0, Simrounds)
ARIResultsGapER = rep(0, Simrounds)
ARIResultsStARS = rep(0, Simrounds)
ARIResultsPC = rep(0, Simrounds)
ARIResultsAGNES = rep(0, Simrounds)

NMIResultsGapPermute = rep(0, Simrounds)
NMIResultsGapER = rep(0, Simrounds)
NMIResultsStARS = rep(0, Simrounds)
NMIResultsPC = rep(0, Simrounds)
NMIResultsAGNES = rep(0, Simrounds)

lambda_GapPermute = rep(0, Simrounds)
lambda_GapER = rep(0, Simrounds)
lambda_StARS = rep(0, Simrounds)
lambda_PC = rep(0, Simrounds)
lambda_AGNES = rep(0, Simrounds)

Nmb_of_clusters_GapPermute = rep(0, Simrounds)
Nmb_of_clusters_GapER = rep(0, Simrounds)
Nmb_of_clusters_StARS = rep(0, Simrounds)
Nmb_of_clusters_PC = rep(0, Simrounds)
Nmb_of_clusters_AGNES = rep(0, Simrounds)

modularity_GapPermute = rep(0, Simrounds)
modularity_GapER = rep(0, Simrounds)
modularity_StARS = rep(0, Simrounds)
modularity_PC = rep(0, Simrounds)
modularity_AGNES = rep(0, Simrounds)

##########################################################

for(si in 1:Simrounds){
  
  Y = mvrnorm(n, rep(0, p), Sigma)
  
  # Compute nrho GGMs
  
  GSolutionPath = huge::huge(Y, nlambda=nrho, method=NetMethod)
  
  ##########################################################
  
  # Gap-com, permute data
    
  GapPermuteLambda = gap_com_parallel(GSolutionPath, Plot = F, B = 50, method = "permute_sample")
  
  GapPermuteIndex = GapPermuteLambda$opt.index
  
  GGapPermute = graph.adjacency(GSolutionPath$path[[GapPermuteIndex]], mode="undirected", diag=F)
  
  GapPermuteCommunities = walktrap.community(GGapPermute)
  
  ##########################################################
  
  # Gap-com, Erdos-Renyi random graph sampling
    
  GapERLambda = gap_com_parallel(GSolutionPath, Plot = F, B = 50, 
                                   method = "er_sample")
  
  GapERIndex = GapERLambda$opt.index
  
  GGapER = graph.adjacency(GSolutionPath$path[[GapERIndex]], mode="undirected", diag=F)
  
  GapERCommunities = walktrap.community(GGapER)
  
  ##########################################################
  
  # StARS
    
  HugeSelectStARS = huge.select(GSolutionPath, criterion="stars", rep.num = 50, stars.thresh = 0.05)
  
  GStARS = graph.adjacency(as.matrix(HugeSelectStARS$refit), mode="undirected", diag=F)
  
  StARSCommunities = walktrap.community(GStARS)
  
  ##########################################################
  
  # Path connectivity (PC):
  
  d = lambdaSelection(GSolutionPath, criterion = "PC")
  
  PCOptLambda = d$opt.lambda
  
  PCIndex = which(GSolutionPath$lambda == PCOptLambda)
  
  GPC = graph.adjacency(GSolutionPath$path[[PCIndex]], mode="undirected", diag=F)
  
  PCCommunities = walktrap.community(GPC)
  
  # AGlommerative NESted (AGNES):
  
  d = lambdaSelection(GSolutionPath, criterion = "AG")
  
  AGNESOptLambda = d$opt.lambda
  
  AGNESIndex = which(GSolutionPath$lambda == AGNESOptLambda)
  
  GAGNES = graph.adjacency(GSolutionPath$path[[AGNESIndex]], mode="undirected", diag=F)
  
  AGNESCommunities = walktrap.community(GAGNES)
  
  ##########################################################
  
  # What is the best the network estimation method can do, condition to the solution path at hand?
  
  AllTheBest = matrix(0, nrho, 5)
  
  for(i in 1:nrho){
    
    AllTheBest[i, ] = unlist(Diagnostic(as.matrix(GSolutionPath$path[[i]]), TrueA))
    
  }
  
  BestSp[si] = max(AllTheBest[ , 1], na.rm = T) # Choose the graphical model that produces the best estimate of specificity
  BestSen[si] = max(AllTheBest[ , 2], na.rm = T) # Choose the graphical model that produces the best estimate of sensitivity
  BestFall[si] = min(AllTheBest[ , 3], na.rm = T) # Choose the graphical model that produces the best estimate of fall-out
  BestPre[si] = max(AllTheBest[ , 4], na.rm = T) # Choose the graphical model that produces the best estimate of precision
  BestMCC[si] = max(AllTheBest[ , 5], na.rm = T) # Choose the graphical model that produces the best estimate of MCC
  
  ##########################################################
  ##########################################################
  
  GapPermuteResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[GapPermuteIndex]])))
  
  GapERResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[GapERIndex]])))
  
  StARSResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(HugeSelectStARS$refit)))
  
  PCResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[PCIndex]])))
  
  AGNESResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[AGNESIndex]])))
  
  ##########################################################
  
  ARIResultsGapPermute[si] = igraph::compare(GapPermuteCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsGapER[si] = igraph::compare(GapERCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsStARS[si] = igraph::compare(StARSCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsPC[si] = igraph::compare(PCCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsAGNES[si] = igraph::compare(AGNESCommunities, TrueCommunities, method="adjusted.rand")
  
  ##########################################################
  
  NMIResultsGapPermute[si] = igraph::compare(GapPermuteCommunities, TrueCommunities, method="nmi")
  
  NMIResultsGapER[si] = igraph::compare(GapERCommunities, TrueCommunities, method="nmi")
  
  NMIResultsStARS[si] = igraph::compare(StARSCommunities, TrueCommunities, method="nmi")
  
  NMIResultsPC[si] = igraph::compare(PCCommunities, TrueCommunities, method="nmi")
  
  NMIResultsAGNES[si] = igraph::compare(AGNESCommunities, TrueCommunities, method="nmi")
  
  #Pick the selected value of the tuning parameter...
  
  lambda_GapPermute[si] = GapPermuteLambda$opt.lambda
  
  lambda_GapER[si] = GapERLambda$opt.lambda
  
  lambda_StARS[si] = HugeSelectStARS$opt.lambda
  
  lambda_PC[si] = PCOptLambda
  
  lambda_AGNES[si] = AGNESOptLambda
  
  #... and the number of communities,
  
  Nmb_of_clusters_GapPermute[si] = length(unique(GapPermuteCommunities$membership))
  
  Nmb_of_clusters_GapER[si] = length(unique(GapERCommunities$membership))
  
  Nmb_of_clusters_StARS[si] = length(unique(StARSCommunities$membership))
  
  Nmb_of_clusters_PC[si] = length(unique(PCCommunities$membership))
  
  Nmb_of_clusters_AGNES[si] = length(unique(AGNESCommunities$membership))
  
  #... and modularity.
  
  modularity_GapPermute[si] = modularity(GapPermuteCommunities)
  
  modularity_GapER[si] = modularity(GapERCommunities)
  
  modularity_StARS[si] = modularity(StARSCommunities)
  
  modularity_PC[si] = modularity(PCCommunities)
  
  modularity_AGNES[si] = modularity(AGNESCommunities)
  
  cat("\r",si)
  
}

BestResults[ , 1] = BestSp
BestResults[ , 2] = BestSen
BestResults[ , 3] = BestFall
BestResults[ , 4] = BestPre
BestResults[ , 5] = BestMCC

# Plot networks

plot(TrueG, vertex.label = NA, vertex.size = 2) # Truth
title("Ground truth")

plot(GGapPermute, vertex.label = NA, vertex.size = 2) # Truth
title("Gap-com, Permute sample")

plot(GGapER, vertex.label = NA, vertex.size = 2) # Truth
title("Gap-com, E-R sample")

plot(GStARS, vertex.label = NA, vertex.size = 2) # Truth
title("StARS")

plot(GPC, vertex.label = NA, vertex.size = 2) # Truth
title("PC")

plot(GAGNES, vertex.label = NA, vertex.size = 2) # Truth
title("AGNES")

#####################################################
#####################################################

par(mfrow=c(2, 3))

boxplot(GapPermuteResults, ylim=c(0, 1))
title("Gap-com, Permute")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(GapERResults, ylim=c(0, 1))
title("Gap-com, E-R")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(StARSResults, ylim=c(0, 1))
title("StARS")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(PCResults, ylim=c(0, 1))
title("PC")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(AGNESResults, ylim=c(0, 1))
title("AGNES")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

par(mfrow=c(1, 2))

boxplot(ARIResultsGapPermute, ARIResultsGapER, ARIResultsStARS, ARIResultsPC, ARIResultsAGNES,
        names = c("Gap-com, Permute", "Gap-com, ER", "StARS", "PC", "AGNES"))

title("Adjusted Rand index")

boxplot(NMIResultsGapPermute, NMIResultsGapER, NMIResultsStARS, NMIResultsPC, NMIResultsAGNES,
        names = c("Gap-com, Permute", "Gap-com, ER", "StARS", "PC", "AGNES"))

title("Normalized mutual information measure")

#####################################################

GapPermuteResults = data.frame("Method" = rep("Gap-com-permute", Simrounds), GapPermuteResults)

GapERResults = data.frame("Method" = rep("Gap-com-ER", Simrounds), GapERResults)

StARSResults = data.frame("Method" = rep("StARS", Simrounds), StARSResults)

PCResults = data.frame("Method" = rep("PC", Simrounds), PCResults)

AGNESResults = data.frame("Method" = rep("AGNES", Simrounds), AGNESResults)

BestResults = data.frame("Method" = rep("Oracle", Simrounds), BestResults)

MergedResults = rbind(GapPermuteResults, GapERResults, StARSResults, PCResults, AGNESResults, BestResults)

#####################################################

GapPermuteResultsARI = data.frame("Method" = rep("Gap-com-permute", Simrounds), "ARI" = ARIResultsGapPermute)

GapERResultsARI = data.frame("Method" = rep("Gap-com-ER", Simrounds), "ARI" = ARIResultsGapER)

StARSResultsARI = data.frame("Method" = rep("StARS", Simrounds), "ARI" = ARIResultsStARS)

PCResultsARI = data.frame("Method" = rep("PC", Simrounds), "ARI" = ARIResultsPC)

AGNESResultsARI = data.frame("Method" = rep("AGNES", Simrounds), "ARI" = ARIResultsAGNES)

MergedResultsARI = rbind(GapPermuteResultsARI, GapERResultsARI, StARSResultsARI, PCResultsARI, AGNESResultsARI)

#####################################################

GapPermuteResultsNMI = data.frame("Method" = rep("Gap-com-permute", Simrounds), "NMI" = NMIResultsGapPermute)

GapERResultsNMI = data.frame("Method" = rep("Gap-com-ER", Simrounds), "NMI" = NMIResultsGapER)

StARSResultsNMI = data.frame("Method" = rep("StARS", Simrounds), "NMI" = NMIResultsStARS)

PCResultsNMI = data.frame("Method" = rep("PC", Simrounds), "NMI" = NMIResultsPC)

AGNESResultsNMI = data.frame("Method" = rep("AGNES", Simrounds), "NMI" = NMIResultsAGNES)

MergedResultsNMI = rbind(GapPermuteResultsNMI, GapERResultsNMI, StARSResultsNMI, PCResultsNMI, AGNESResultsNMI)

#####################################################

GapPermuteResultslambda = data.frame("Method" = rep("Gap-com-permute", Simrounds), "lambda" = lambda_GapPermute)

GapERResultslambda = data.frame("Method" = rep("Gap-com-ER", Simrounds), "lambda" = lambda_GapER)

StARSResultslambda = data.frame("Method" = rep("StARS", Simrounds), "lambda" = lambda_StARS)

PCResultslambda = data.frame("Method" = rep("PC", Simrounds), "lambda" = lambda_PC)

AGNESResultslambda = data.frame("Method" = rep("AGNES", Simrounds), "lambda" = lambda_AGNES)

MergedResultslambda = rbind(GapPermuteResultslambda, GapERResultslambda, StARSResultslambda, PCResultslambda, AGNESResultslambda)

#####################################################

GapPermuteResults_nmb_of_clusters = data.frame("Method" = rep("Gap-com-permute", Simrounds), 
                                               "nmb.of.clusters" = Nmb_of_clusters_GapPermute)

GapERResults_nmb_of_clusters = data.frame("Method" = rep("Gap-com-ER", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_GapER)

StARSResults_nmb_of_clusters = data.frame("Method" = rep("StARS", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_StARS)

PCResults_nmb_of_clusters = data.frame("Method" = rep("PC", Simrounds), 
                                       "nmb.of.clusters" = Nmb_of_clusters_PC)

AGNESResults_nmb_of_clusters = data.frame("Method" = rep("AGNES", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_AGNES)

MergedResults_nmb_of_clusters = rbind(GapPermuteResults_nmb_of_clusters, 
                                      GapERResults_nmb_of_clusters, 
                                      StARSResults_nmb_of_clusters, 
                                      PCResults_nmb_of_clusters, 
                                      AGNESResults_nmb_of_clusters)

#####################################################

GapPermuteResults_modularity = data.frame("Method" = rep("Gap-com-permute", Simrounds), 
                                          "modularity" = modularity_GapPermute)

GapERResults_modularity = data.frame("Method" = rep("Gap-com-ER", Simrounds), 
                                     "modularity" = modularity_GapER)

StARSResults_modularity = data.frame("Method" = rep("StARS", Simrounds), 
                                     "modularity" = modularity_StARS)

PCResults_modularity = data.frame("Method" = rep("PC", Simrounds), 
                                  "modularity" = modularity_PC)

AGNESResults_modularity = data.frame("Method" = rep("AGNES", Simrounds), 
                                     "modularity" = modularity_AGNES)

MergedResults_modularity = rbind(GapPermuteResults_modularity, 
                                 GapERResults_modularity, 
                                 StARSResults_modularity, 
                                 PCResults_modularity, 
                                 AGNESResults_modularity)

#####################################################

write.table(MergedResults, 
            paste("Results/Classification_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""), 
            quote = F)

write.table(MergedResultsARI, 
            paste("Results/ARI_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""), 
            quote = F)

write.table(MergedResultsNMI,
            paste("Results/NMI_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(MergedResultslambda, 
            paste("Results/lambda_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(MergedResults_nmb_of_clusters, 
            paste("Results/nmb_of_clusters_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(MergedResults_modularity, 
            paste("Results/modularity_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)
