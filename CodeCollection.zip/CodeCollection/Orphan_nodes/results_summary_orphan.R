
# 9.9.2021

# Summarize the results when there are orphan nodes in the ground truth network,

library(ggplot2)
library(reshape2)

Model = "scale-free" # hub, cluster, random or scale-free

Metric = "Classification" # ARI, NMI, lambda, modularity, nmb_of_clusters or Classification

path_to_file = paste0("Results/", Metric ,"_ct_", Model, "_n=200p=500_Class.res.txt")

Data = read.table(path_to_file)

Data$Method[Data$Method == "Gap-com-permute"] = "gap-com (permute)"

Data$Method[Data$Method == "Gap-com-ER"] = "gap-com (ER)"

if(Metric == "Classification"){
  
  Data = reshape2::melt(Data)
 
  colnames(Data) = c("Method", "Metric", "Value")
  
  Pre <- Data %>% 
    dplyr::filter(Metric == "Pre") %>% 
    dplyr::group_by(Method) %>% 
    dplyr::summarize(`Precision mean` = mean(Value))
  
  MCC <- Data %>% 
    dplyr::filter(Metric == "MCC") %>% 
    dplyr::group_by(Method) %>% 
    dplyr::summarize(`MCC mean` = mean(Value))
   
}

Pre

MCC

if(Metric == "Classification"){
  
  P = ggplot(Data, aes(x = Method, y=Value, fill=Metric)) +
    geom_boxplot() +
    theme(legend.position="bottom", axis.text=element_text(size = 7),
          axis.title=element_text(size = 10, face = "bold"))
  
}else{
  
  P = ggplot(data = Data, aes(x = Method, y = !!sym(Metric))) +
    geom_boxplot() + 
    theme(legend.position = "bottom", axis.text = element_text(size = 8),
          axis.title=element_text(size = 10, face = "bold")) +
    xlab("Method")
  
}

P

BBName = paste("Boxplots/ct_", Model, "_", Metric, ".png", sep="")

ggsave(BBName, P, width = 5, height = 4, dpi=600, units = "in")

