# 1.7.2021

# Construct the community network

library(igraph)
library(spatstat)

SAureusCommunityNet = read.table("S_aureus_community_network.txt",sep="\t",header = F)

SAureusCommunityNet[1:10,]

sum(SAureusCommunityNet[, 1] == "SAV0522")

sum(SAureusCommunityNet[, 2] == "SAV0522")

# In Marbach et al (2012) they selected just 1688 edges...

SAureusCommunityNet = SAureusCommunityNet[,1:2]

SAureusCommunityNet = SAureusCommunityNet[1:1688, ]

colnames(SAureusCommunityNet) = c("col1","col2")

SAureusCommunityNet[1:10,]


SAureusCommunityNet = graph.data.frame(SAureusCommunityNet, directed = F)

gsize(SAureusCommunityNet) # 1688

A_SaureusCommunity = as_adjacency_matrix(SAureusCommunityNet, edges = F, type="both")

A_SaureusCommunity = as.matrix(A_SaureusCommunity)

isSymmetric(A_SaureusCommunity)

A_SaureusCommunity[1:5,1:5]

A_SaureusCommunity = ifelse(A_SaureusCommunity != 0, 1, 0)

dim(A_SaureusCommunity)

summary(colSums(A_SaureusCommunity))

A_SaureusCommunity[1:5,1:5]

sum(A_SaureusCommunity[upper.tri(A_SaureusCommunity)]) # Should be 1688

f = function(m) t(m)[nrow(m):1,] # For plotting the images
plot(im(f(A_SaureusCommunity)), main="Real Adjacency",col = gray(seq(1,0,length.out=10)))

CW = cluster_walktrap(SAureusCommunityNet)

coords = layout_with_fr(SAureusCommunityNet, grid="nogrid")

length(table(membership(CW)))

NetColors = rainbow(length(table(membership(CW))))

GroupCol = NetColors[membership(CW)]


pdf("SAureusCommunityNet.pdf", onefile=T, paper='A4r')

par(mfrow=c(1,1))

plot(CW, SAureusCommunityNet, mark.border=NA, mark.col = NA,layout=coords, vertex.label=NA, edge.arrow.size=.2,
     edge.color = "black", col=GroupCol, vertex.size = 2,main="In SAureus Network")

dev.off()

igraph::neighborhood(SAureusCommunityNet, nodes = "SAV2357") # This is the "transcription regulator"

length(igraph::neighborhood(SAureusCommunityNet, nodes = "SAV2357")[[1]]) # What are these six extra genes...

# Look each neighbor separately,

igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0814") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV2503") #Fibornectin binding protein 
igraph::neighborhood(SAureusCommunityNet, nodes = "SA1755") # Not shown in Marbach et al 2012
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0717") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SACOL0468") # exotoxin 3, not shown in Marbach et al 2012
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0715") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0718") # SAV0543 not shown in Marbach et al 2012
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0708") # SAV2295 not shown in...
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0716")  
igraph::neighborhood(SAureusCommunityNet, nodes = "SACOL0767") # Not shown in...
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0849") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0435") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0714") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0429") # exotoxin 14
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0423") # exotoxin 7
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV1105") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SACOL0857") # Not shown in...
igraph::neighborhood(SAureusCommunityNet, nodes = "SACOL1046") # Not shown in...
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0220") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV1159") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0229") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV2001") 
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0424") # exotoxin 8
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0426") # exotoxin 11
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0749") 

igraph::neighborhood(SAureusCommunityNet, nodes = "SAV2553") # This is the "Tetracycline repressor", 
                                                             # or at least it has the same neighbors...

# Look also here each neighbor separately,

igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0825")
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV1049")
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0715")
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0718")
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0716")
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV1431")
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV0714")
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV2221")
igraph::neighborhood(SAureusCommunityNet, nodes = "SAV2222")
