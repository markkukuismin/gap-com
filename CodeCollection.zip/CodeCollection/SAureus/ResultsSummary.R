
# 8.5.2018

# Summary of the results

A=read.table("LargestClusterDiagnostics.txt")
B=read.table("LargestClusterTrueMembersPresent.txt")
C=read.table("NmbOfHubsFoundOutOf5.txt")
D=read.table("HubHighestDegreeNeighborsDiagnostics.txt")

# How well is the largest cluster identified:
100*A

# The largest cluster (percentage of true positives):
B

# Nmb of correctly identified hub nodes. Zero if not correctly identified:
boxplot(C)

# How well is the neighborhood of the hub node with the highest degree identified:
100*D
