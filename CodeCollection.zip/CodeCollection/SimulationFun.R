
# 03.06.2020

# Choose tuning parameter using gap-com statistic:

library(MASS)
library(huge)
library(GMRPS)
library(BigQuic)
library(igraph)
library(ggplot2)
library(foreach)
library(parallel)
library(doParallel)

registerDoParallel(cores=detectCores(all.tests=TRUE))


source("Rfunctions/SpSeFallPreMCC.txt")
source("Rfunctions/gap_com.R")
source("Rfunctions/gap_com_parallel.R")
source("RFunctions/ModifyBigQUIC.R")
source("RFunctions/gap_com_BigQuic_parallel.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 9809

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 500 # 500 or 1000

Model = "scale-free" # scale-free, hub or cluster

NetMethod = "BQ" # Method used to construct the sparse network. Either ct or BQ

g = 10 # Nmb of true clusters and/or hub nodes

HugeData = huge.generator(n=10, d=p, graph=Model, g=g) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

Sigma = HugeData$sigma

TrueA = as.matrix(HugeData$theta) # True GGM adjacency matrix

TrueG = graph.adjacency(TrueA, mode="undirected", diag=F)

TrueCommunities = walktrap.community(TrueG)

n = 200 # Sample size

nrho = 50 # nmb of used tuning parameters

##########################################################

Simrounds = 100

BestSp = rep(0, Simrounds)
BestSen = rep(0, Simrounds) 
BestFall = rep(0, Simrounds)
BestPre = rep(0, Simrounds)
BestMCC = rep(0, Simrounds)

GapUnifResults = matrix(0, Simrounds, 5)
colnames(GapUnifResults) = c("Sp", "Sen", "Fall", "Pre", "MCC")

GapERResults = GapUnifResults
StARSResults = GapUnifResults
PCResults = GapUnifResults
AGNESResults = GapUnifResults

BestResults = GapUnifResults # For orcale method

ARIResultsGapUnif = rep(0, Simrounds)
ARIResultsGapER = rep(0, Simrounds)
ARIResultsStARS = rep(0, Simrounds)
ARIResultsPC = rep(0, Simrounds)
ARIResultsAGNES = rep(0, Simrounds)

NMIResultsGapUnif = rep(0, Simrounds)
NMIResultsGapER = rep(0, Simrounds)
NMIResultsStARS = rep(0, Simrounds)
NMIResultsPC = rep(0, Simrounds)
NMIResultsAGNES = rep(0, Simrounds)

##########################################################

for(si in 1:Simrounds){
  
  Y = mvrnorm(n, rep(0, p), Sigma)
  
  # Compute nrho GGMs
  
  if(NetMethod == "ct") GSolutionPath = huge(Y, nlambda=nrho, method=NetMethod)
  
  if(NetMethod == "BQ"){
    
    lambda.min.ratio = 0.4
 
    # Create a grid of log-spaced tuning parameter values
    
    S = var(scale(Y))
    
    lambda.max = max(max(S - diag(p)), -min(S - diag(p)))
    
    lambda.min = lambda.min.ratio * lambda.max
    
    lambda = exp(seq(log(lambda.max), log(lambda.min), length = nrho))
    
    BQSolPath = BigQuic(Y, outputFileName = "BigQuicMatrix", lambda = lambda,
                        numthreads = detectCores(all.tests=TRUE))
    
    GSolutionPath = ModifyBigQUIC(BQSolPath)
    
  } 
  
  ##########################################################
  
  # Gap-com, uniform sample
  
  if(NetMethod == "ct"){
    
    GapUnifLambda = gap_com_parallel(GSolutionPath, Plot = F, B = 50, method = "unif_sample")
    
  }
  
  if(NetMethod == "BQ"){
    
    GapUnifLambda = gap_com_BigQuic_parallel(BQSolPath, Plot = F,
                                                              method = "unif_sample")
    
  }
  
  GapUnifIndex = GapUnifLambda$opt.index
  
  GGapUnif = graph.adjacency(GSolutionPath$path[[GapUnifIndex]], mode="undirected", diag=F)
  
  GapUnifCommunities = walktrap.community(GGapUnif)
  
  ##########################################################
  
  # Gap-com, Erdos-Renyi random graph sampling
  
  if(NetMethod == "ct"){
    
    GapERLambda = gap_com_parallel(GSolutionPath, Plot = F, B = 50, 
                                   method = "er_sample")
    
  }
  
  if(NetMethod == "BQ"){
    
    GapERLambda = gap_com_BigQuic_parallel(BQSolPath, Plot = F,
                                             method = "er_sample")
    
  }
  
  GapERIndex = GapERLambda$opt.index
  
  GGapER = graph.adjacency(GSolutionPath$path[[GapERIndex]], mode="undirected", diag=F)
  
  GapERCommunities = walktrap.community(GGapER)
  
  ##########################################################
  
  # StARS
    
  if(NetMethod == "ct"){
    
    HugeSelectStARS = huge.select(GSolutionPath, criterion="stars", rep.num = 50, stars.thresh = 0.05)
    
  }
  
  if(NetMethod == "BQ"){
    
    HugeSelectStARS = BigQuic.select(BQSolPath, stars.thresh = 0.05, 
                   rep.num = 50, verbose = F, verbose2 = 0)
    
    StARSInd = which(lambda == HugeSelectStARS$opt.lambda)
    
    refit = GSolutionPath$path[[StARSInd]]
    
    HugeSelectStARS = list(refit = refit)
    
  }
  
  GStARS = graph.adjacency(as.matrix(HugeSelectStARS$refit), mode="undirected", diag=F)
  
  StARSCommunities = walktrap.community(GStARS)
  
  ##########################################################
  
  # Path connectivity (PC):
  
  d = lambdaSelection(GSolutionPath, criterion = "PC")
  
  PCOptLambda = d$opt.lambda

  PCIndex = which(GSolutionPath$lambda == PCOptLambda)
  
  GPC = graph.adjacency(GSolutionPath$path[[PCIndex]], mode="undirected", diag=F)
  
  PCCommunities = walktrap.community(GPC)
  
  # AGlommerative NESted (AGNES):
  
  d = lambdaSelection(GSolutionPath, criterion = "AG")
  
  AGNESOptLambda = d$opt.lambda
  
  AGNESIndex = which(GSolutionPath$lambda == AGNESOptLambda)
  
  GAGNES = graph.adjacency(GSolutionPath$path[[AGNESIndex]], mode="undirected", diag=F)
  
  AGNESCommunities = walktrap.community(GAGNES)
  
  ##########################################################
  
  # What is the best the network method can do, condition to the solution path at hand?
  
  AllTheBest = matrix(0, nrho, 5)
  
  for(i in 1:nrho){
    
    AllTheBest[i, ] = unlist(Diagnostic(as.matrix(GSolutionPath$path[[i]]), TrueA))
    
  }
  
  BestSp[si] = max(AllTheBest[ , 1], na.rm = T) # Choose the graphical model that produces the best estimate of specificity
  BestSen[si] = max(AllTheBest[ , 2], na.rm = T) # Choose the graphical model that produces the best estimate of sensitivity
  BestFall[si] = min(AllTheBest[ , 3], na.rm = T) # Choose the graphical model that produces the best estimate of fall-out
  BestPre[si] = max(AllTheBest[ , 4], na.rm = T) # Choose the graphical model that produces the best estimate of precision
  BestMCC[si] = max(AllTheBest[ , 5], na.rm = T) # Choose the graphical model that produces the best estimate of MCC
  
  ##########################################################
  ##########################################################
  
  GapUnifResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[GapUnifIndex]])))
  
  GapERResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[GapERIndex]])))
  
  StARSResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(HugeSelectStARS$refit)))
  
  PCResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[PCIndex]])))
  
  AGNESResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[AGNESIndex]])))

  ##########################################################
  
  ARIResultsGapUnif[si] = compare(GapUnifCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsGapER[si] = compare(GapERCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsStARS[si] = compare(StARSCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsPC[si] = compare(PCCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsAGNES[si] = compare(AGNESCommunities, TrueCommunities, method="adjusted.rand")
  
  ##########################################################
  
  NMIResultsGapUnif[si] = compare(GapUnifCommunities, TrueCommunities, method="nmi")
  
  NMIResultsGapER[si] = compare(GapERCommunities, TrueCommunities, method="nmi")
  
  NMIResultsStARS[si] = compare(StARSCommunities, TrueCommunities, method="nmi")
  
  NMIResultsPC[si] = compare(PCCommunities, TrueCommunities, method="nmi")
  
  NMIResultsAGNES[si] = compare(AGNESCommunities, TrueCommunities, method="nmi")
  
  if(NetMethod == "BQ"){
    
    files = list.files(pattern = "\\.output$")
    
    invisible(file.remove(files))
    
  }
  
  cat("\r",si)
  
}

BestResults[ , 1] = BestSp
BestResults[ , 2] = BestSen
BestResults[ , 3] = BestFall
BestResults[ , 4] = BestPre
BestResults[ , 5] = BestMCC

# Plot networks

huge.plot(HugeData$theta) # Truth
title("Ground truth")

huge.plot(GSolutionPath$path[[GapUnifLambda$opt.index]])
title("Gap-com, unif sample")

huge.plot(GSolutionPath$path[[GapERLambda$opt.index]])
title("Gap-com, E-R sample")

huge.plot(HugeSelectStARS$refit)
title("StARS")

huge.plot(GSolutionPath$path[[PCIndex]])# eBIC
title("PC")

huge.plot(GSolutionPath$path[[AGNESIndex]])
title("AGNES")

#####################################################
#####################################################

par(mfrow=c(2, 3))

boxplot(GapUnifResults, ylim=c(0, 1))
title("Gap-com, unif")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(GapERResults, ylim=c(0, 1))
title("Gap-com, E-R")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(StARSResults, ylim=c(0, 1))
title("StARS")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(PCResults, ylim=c(0, 1))
title("PC")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(AGNESResults, ylim=c(0, 1))
title("AGNES")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

par(mfrow=c(1, 2))

boxplot(ARIResultsGapUnif, ARIResultsGapER, ARIResultsStARS, ARIResultsPC, ARIResultsAGNES,
        names = c("Gap-com, unif", "Gap-com, ER", "StARS", "PC", "AGNES"))

title("Adjusted Rand index")

boxplot(NMIResultsGapUnif, NMIResultsGapER, NMIResultsStARS, NMIResultsPC, NMIResultsAGNES,
        names = c("Gap-com, unif", "Gap-com, ER", "StARS", "PC", "AGNES"))

title("Normalized mutual information measure")

#####################################################

GapUnifResults = data.frame("Method" = rep("Gap-com-unif", Simrounds), GapUnifResults)

GapERResults = data.frame("Method" = rep("Gap-com-ER", Simrounds), GapERResults)

StARSResults = data.frame("Method" = rep("StARS", Simrounds), StARSResults)

PCResults = data.frame("Method" = rep("PC", Simrounds), PCResults)

AGNESResults = data.frame("Method" = rep("AGNES", Simrounds), AGNESResults)

BestResults = data.frame("Method" = rep("Oracle", Simrounds), BestResults)

MergedResults = rbind(GapUnifResults, GapERResults, StARSResults, PCResults, AGNESResults, BestResults)

#####################################################

GapUnifResultsARI = data.frame("Method" = rep("Gap-com-unif", Simrounds), "ARI" = ARIResultsGapUnif)

GapERResultsARI = data.frame("Method" = rep("Gap-com-ER", Simrounds), "ARI" = ARIResultsGapER)

StARSResultsARI = data.frame("Method" = rep("StARS", Simrounds), "ARI" = ARIResultsStARS)

PCResultsARI = data.frame("Method" = rep("PC", Simrounds), "ARI" = ARIResultsPC)

AGNESResultsARI = data.frame("Method" = rep("AGNES", Simrounds), "ARI" = ARIResultsAGNES)

MergedResultsARI = rbind(GapUnifResultsARI, GapERResultsARI, StARSResultsARI, PCResultsARI, AGNESResultsARI)

#####################################################

GapUnifResultsNMI = data.frame("Method" = rep("Gap-com-unif", Simrounds), "NMI" = NMIResultsGapUnif)

GapERResultsNMI = data.frame("Method" = rep("Gap-com-ER", Simrounds), "NMI" = NMIResultsGapER)

StARSResultsNMI = data.frame("Method" = rep("StARS", Simrounds), "NMI" = NMIResultsStARS)

PCResultsNMI = data.frame("Method" = rep("PC", Simrounds), "NMI" = NMIResultsPC)

AGNESResultsNMI = data.frame("Method" = rep("AGNES", Simrounds), "NMI" = NMIResultsAGNES)

MergedResultsNMI = rbind(GapUnifResultsNMI, GapERResultsNMI, StARSResultsNMI, PCResultsNMI, AGNESResultsNMI)

#####################################################

write.table(MergedResults, paste("Results/Classification_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", 
                                 sep=""), quote = F)

write.table(MergedResultsARI, paste("Results/ARI_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", 
                                    sep=""), quote = F)

write.table(MergedResultsNMI, paste("Results/NMI_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)
