
# 18.06.2021

# Choose tuning parameter using gap-com statistic and evaluate the performance.
# In addition, compare the performance to some other graphical model selection
# methods.

# Before you start, set the working directory. In R Studio, this can be done
# from the toolbar: 

# "Session - Set Working Directory - To Source File Location"

# First, load the necessary R packages:

library(MASS)
library(huge)
library(GMRPS)
library(BigQuic)
library(igraph)
library(ggplot2)
library(foreach)
library(parallel)
library(doParallel)

# To speed up computations, use parallel computing:

registerDoParallel(cores=detectCores(all.tests=TRUE))

# Run my own R function found in the folder "Rfunctions".

source("Rfunctions/SpSeFallPreMCC.txt")
source("Rfunctions/gap_com.R")
source("Rfunctions/gap_com_parallel.R")
source("RFunctions/ModifyBigQUIC.R")
source("RFunctions/gap_com_BigQuic_parallel.R")
source("RFunctions/gap_com_BQ.R")
source("RFunctions/BQSparsity.R") # A help-function
source("RFunctions/gap_com_parallel_BQ.R") # Like function "gap_com_BigQuic_parallel" but this uses RAM

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 9809

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 500 # 500 or 1000 (the number of nodes)

Model = "scale-free" # scale-free, hub, cluster or random (Erdos-Renyi)

NetMethod = "BQ" # Method used to construct the sparse network. Either ct (correlation thresholding) or BQ (Big Quic)

g = 10 # Nmb of true clusters and/or hubs in the network 

HugeData = huge.generator(n = 10, d = p, graph = Model, g = g) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

if(Model == "random") HugeData = huge.generator(n = 10, d = p, graph = Model, prob = 0.263)

Sigma = HugeData$sigma

TrueA = as.matrix(HugeData$theta) # True GGM adjacency matrix

TrueG = graph.adjacency(TrueA, mode="undirected", diag=F)

TrueCommunities = walktrap.community(TrueG)

TrueNmbofClusters = length(unique(TrueCommunities$membership))

n = 200 # Sample size

nrho = 50 # nmb of used tuning parameters

##########################################################

Simrounds = 100

BestSp = rep(0, Simrounds)
BestSen = rep(0, Simrounds) 
BestFall = rep(0, Simrounds)
BestPre = rep(0, Simrounds)
BestMCC = rep(0, Simrounds)

GapPermuteResults = matrix(0, Simrounds, 5)
colnames(GapPermuteResults) = c("Sp", "Sen", "Fall", "Pre", "MCC")

GapERResults = GapPermuteResults
StARSResults = GapPermuteResults
PCResults = GapPermuteResults
AGNESResults = GapPermuteResults

BestResults = GapPermuteResults # For oracle method

ARIResultsGapPermute = rep(0, Simrounds)
ARIResultsGapER = rep(0, Simrounds)
ARIResultsStARS = rep(0, Simrounds)
ARIResultsPC = rep(0, Simrounds)
ARIResultsAGNES = rep(0, Simrounds)

NMIResultsGapPermute = rep(0, Simrounds)
NMIResultsGapER = rep(0, Simrounds)
NMIResultsStARS = rep(0, Simrounds)
NMIResultsPC = rep(0, Simrounds)
NMIResultsAGNES = rep(0, Simrounds)

lambda_GapPermute = rep(0, Simrounds)
lambda_GapER = rep(0, Simrounds)
lambda_StARS = rep(0, Simrounds)
lambda_PC = rep(0, Simrounds)
lambda_AGNES = rep(0, Simrounds)

Nmb_of_clusters_GapPermute = rep(0, Simrounds)
Nmb_of_clusters_GapER = rep(0, Simrounds)
Nmb_of_clusters_StARS = rep(0, Simrounds)
Nmb_of_clusters_PC = rep(0, Simrounds)
Nmb_of_clusters_AGNES = rep(0, Simrounds)

Nmb_of_clusters_nonzero_GapPermute = rep(0, Simrounds)
Nmb_of_clusters_nonzero_GapER = rep(0, Simrounds)
Nmb_of_clusters_nonzero_StARS = rep(0, Simrounds)
Nmb_of_clusters_nonzero_PC = rep(0, Simrounds)
Nmb_of_clusters_nonzero_AGNES = rep(0, Simrounds)

modularity_GapPermute = rep(0, Simrounds)
modularity_GapER = rep(0, Simrounds)
modularity_StARS = rep(0, Simrounds)
modularity_PC = rep(0, Simrounds)
modularity_AGNES = rep(0, Simrounds)

##########################################################

for(si in 1:Simrounds){
  
  Y = mvrnorm(n, rep(0, p), Sigma)
  
  # Compute nrho GGMs
  
  if(NetMethod == "ct") GSolutionPath = huge(Y, nlambda=nrho, method=NetMethod)
  
  if(NetMethod == "BQ"){
    
    lambda.min.ratio = 0.4
 
    # Create a grid of log-spaced tuning parameter values
    
    S = var(scale(Y))
    
    lambda.max = max(max(S - diag(p)), -min(S - diag(p)))
    
    lambda.min = lambda.min.ratio * lambda.max
    
    lambda = exp(seq(log(lambda.max), log(lambda.min), length = nrho))
    
    BQSolPath = BigQuic(Y, outputFileName = "BigQuicMatrix", lambda = lambda,
                        numthreads = 6, use_ram = T)
    
    GSolutionPath = ModifyBigQUIC(BQSolPath)
    
  } 
  
  ##########################################################
  
  # Gap-com, permute data
  
  if(NetMethod == "ct"){
    
    GapPermuteLambda = gap_com_parallel(GSolutionPath, Plot = F, B = 50, method = "permute_sample")
    
  }
  
  if(NetMethod == "BQ"){
    
    #GapPermuteLambda = gap_com_BigQuic_parallel(BQSolPath, Plot = F,
    #                                                          method = "permute_sample")
    
    GapPermuteLambda = gap_com_parallel_BQ(BQSolPath, Plot = F, method = "permute_sample")
    
    
    
  }
  
  GapPermuteIndex = GapPermuteLambda$opt.index
  
  GGapPermute = graph.adjacency(GSolutionPath$path[[GapPermuteIndex]], mode="undirected", diag=F)
  
  GapPermuteCommunities = walktrap.community(GGapPermute)
  
  ##########################################################
  
  # Gap-com, Erdos-Renyi random graph sampling
  
  if(NetMethod == "ct"){
    
    GapERLambda = gap_com_parallel(GSolutionPath, Plot = F, B = 50, 
                                   method = "er_sample")
    
  }
  
  if(NetMethod == "BQ"){
    
    #GapERLambda = gap_com_BigQuic_parallel(BQSolPath, Plot = F,
    #                                         method = "er_sample")
    
    GapERLambda = gap_com_parallel_BQ(BQSolPath, Plot = F, method = "er_sample")
    
  }
  
  GapERIndex = GapERLambda$opt.index
  
  GGapER = graph.adjacency(GSolutionPath$path[[GapERIndex]], mode="undirected", diag=F)
  
  GapERCommunities = walktrap.community(GGapER)
  
  ##########################################################
  
  # StARS
    
  if(NetMethod == "ct"){
    
    HugeSelectStARS = huge.select(GSolutionPath, criterion="stars", rep.num = 50, stars.thresh = 0.05)
    
  }
  
  if(NetMethod == "BQ"){
    
    HugeSelectStARS = BigQuic.select(BQSolPath, stars.thresh = 0.05, 
                   rep.num = 50, verbose = F, verbose2 = 0)
    
    StARSInd = which(lambda == HugeSelectStARS$opt.lambda)
    
    refit = GSolutionPath$path[[StARSInd]]
    
    HugeSelectStARS = list(refit = refit, opt.lambda = HugeSelectStARS$opt.lambda)
    
  }
  
  GStARS = graph.adjacency(as.matrix(HugeSelectStARS$refit), mode="undirected", diag=F)
  
  StARSCommunities = walktrap.community(GStARS)
  
  ##########################################################
  
  # Path connectivity (PC):
  
  d = lambdaSelection(GSolutionPath, criterion = "PC")
  
  PCOptLambda = d$opt.lambda

  PCIndex = which(GSolutionPath$lambda == PCOptLambda)
  
  GPC = graph.adjacency(GSolutionPath$path[[PCIndex]], mode="undirected", diag=F)
  
  PCCommunities = walktrap.community(GPC)
  
  # AGlommerative NESted (AGNES):
  
  d = lambdaSelection(GSolutionPath, criterion = "AG")
  
  AGNESOptLambda = d$opt.lambda
  
  AGNESIndex = which(GSolutionPath$lambda == AGNESOptLambda)
  
  GAGNES = graph.adjacency(GSolutionPath$path[[AGNESIndex]], mode="undirected", diag=F)
  
  AGNESCommunities = walktrap.community(GAGNES)
  
  ##########################################################
  
  # What is the best the network estimation method can do, condition to the solution path at hand?
  
  AllTheBest = matrix(0, nrho, 5)
  
  for(i in 1:nrho){
    
    AllTheBest[i, ] = unlist(Diagnostic(as.matrix(GSolutionPath$path[[i]]), TrueA))
    
  }
  
  BestSp[si] = max(AllTheBest[ , 1], na.rm = T) # Choose the graphical model that produces the best estimate of specificity
  BestSen[si] = max(AllTheBest[ , 2], na.rm = T) # Choose the graphical model that produces the best estimate of sensitivity
  BestFall[si] = min(AllTheBest[ , 3], na.rm = T) # Choose the graphical model that produces the best estimate of fall-out
  BestPre[si] = max(AllTheBest[ , 4], na.rm = T) # Choose the graphical model that produces the best estimate of precision
  BestMCC[si] = max(AllTheBest[ , 5], na.rm = T) # Choose the graphical model that produces the best estimate of MCC
  
  ##########################################################
  
  # Make graphs where isolated nodes are removed,
  
  G_list = list(GGapPermute, GGapER, GStARS, GPC, GAGNES)
  
  CleanedClustersNmb = rep(0, length(G_list))
  
  for(gi in 1:length(G_list)){
    
    degrees = igraph::degree(G_list[[gi]])
    
    remove_nodes = which(degrees <= 1)
    
    GNoIsolated = igraph::delete_vertices(G_list[[gi]], v = remove_nodes)
    
    CommunitiesNoIsolated = igraph::walktrap.community(GNoIsolated)
    
    CleanedClustersNmb[gi] = length(unique(CommunitiesNoIsolated$membership))
    
  }
  
  Nmb_of_clusters_nonzero_GapPermute[si] = CleanedClustersNmb[1]
  
  Nmb_of_clusters_nonzero_GapER[si] = CleanedClustersNmb[2]
  
  Nmb_of_clusters_nonzero_StARS[si] = CleanedClustersNmb[3]
  
  Nmb_of_clusters_nonzero_PC[si] = CleanedClustersNmb[4]
  
  Nmb_of_clusters_nonzero_AGNES[si] = CleanedClustersNmb[5]
  
  ##########################################################
  ##########################################################
  
  GapPermuteResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[GapPermuteIndex]])))
  
  GapERResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[GapERIndex]])))
  
  StARSResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(HugeSelectStARS$refit)))
  
  PCResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[PCIndex]])))
  
  AGNESResults[si, ] = unlist(Diagnostic(TrueA, as.matrix(GSolutionPath$path[[AGNESIndex]])))

  ##########################################################
  
  ARIResultsGapPermute[si] = igraph::compare(GapPermuteCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsGapER[si] = igraph::compare(GapERCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsStARS[si] = igraph::compare(StARSCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsPC[si] = igraph::compare(PCCommunities, TrueCommunities, method="adjusted.rand")
  
  ARIResultsAGNES[si] = igraph::compare(AGNESCommunities, TrueCommunities, method="adjusted.rand")
  
  ##########################################################
  
  NMIResultsGapPermute[si] = igraph::compare(GapPermuteCommunities, TrueCommunities, method="nmi")
  
  NMIResultsGapER[si] = igraph::compare(GapERCommunities, TrueCommunities, method="nmi")
  
  NMIResultsStARS[si] = igraph::compare(StARSCommunities, TrueCommunities, method="nmi")
  
  NMIResultsPC[si] = igraph::compare(PCCommunities, TrueCommunities, method="nmi")
  
  NMIResultsAGNES[si] = igraph::compare(AGNESCommunities, TrueCommunities, method="nmi")
  
  #Pick the selected value of the tuning parameter...
  
  lambda_GapPermute[si] = GapPermuteLambda$opt.lambda
  
  lambda_GapER[si] = GapERLambda$opt.lambda
  
  lambda_StARS[si] = HugeSelectStARS$opt.lambda
  
  lambda_PC[si] = PCOptLambda
  
  lambda_AGNES[si] = AGNESOptLambda
  
  #... and the number of communities,
  
  Nmb_of_clusters_GapPermute[si] = length(unique(GapPermuteCommunities$membership))
    
  Nmb_of_clusters_GapER[si] = length(unique(GapERCommunities$membership))
    
  Nmb_of_clusters_StARS[si] = length(unique(StARSCommunities$membership))
    
  Nmb_of_clusters_PC[si] = length(unique(PCCommunities$membership))
    
  Nmb_of_clusters_AGNES[si] = length(unique(AGNESCommunities$membership))
  
  #... and modularity.
  
  modularity_GapPermute[si] = modularity(GapPermuteCommunities)
  
  modularity_GapER[si] = modularity(GapERCommunities)
  
  modularity_StARS[si] = modularity(StARSCommunities)
  
  modularity_PC[si] = modularity(PCCommunities)
  
  modularity_AGNES[si] = modularity(AGNESCommunities)
  
  
  #if(NetMethod == "BQ"){
    
  #  files = list.files(pattern = "\\.output$")
    
  #  invisible(file.remove(files))
    
  #}
  
  cat("\r",si)
  
}

BestResults[ , 1] = BestSp
BestResults[ , 2] = BestSen
BestResults[ , 3] = BestFall
BestResults[ , 4] = BestPre
BestResults[ , 5] = BestMCC

# Plot networks

huge.plot(HugeData$theta) # Truth
title("Ground truth")

huge.plot(GSolutionPath$path[[GapPermuteLambda$opt.index]])
title("Gap-com, Permute sample")

huge.plot(GSolutionPath$path[[GapERLambda$opt.index]])
title("Gap-com, E-R sample")

huge.plot(HugeSelectStARS$refit)
title("StARS")

huge.plot(GSolutionPath$path[[PCIndex]])# eBIC
title("PC")

huge.plot(GSolutionPath$path[[AGNESIndex]])
title("AGNES")

#####################################################
#####################################################

par(mfrow=c(2, 3))

boxplot(GapPermuteResults, ylim=c(0, 1))
title("Gap-com, Permute")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(GapERResults, ylim=c(0, 1))
title("Gap-com, E-R")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(StARSResults, ylim=c(0, 1))
title("StARS")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(PCResults, ylim=c(0, 1))
title("PC")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(AGNESResults, ylim=c(0, 1))
title("AGNES")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

par(mfrow=c(1, 2))

boxplot(ARIResultsGapPermute, ARIResultsGapER, ARIResultsStARS, ARIResultsPC, ARIResultsAGNES,
        names = c("Gap-com, Permute", "Gap-com, ER", "StARS", "PC", "AGNES"))

title("Adjusted Rand index")

boxplot(NMIResultsGapPermute, NMIResultsGapER, NMIResultsStARS, NMIResultsPC, NMIResultsAGNES,
        names = c("Gap-com, Permute", "Gap-com, ER", "StARS", "PC", "AGNES"))

title("Normalized mutual information measure")

#####################################################

GapPermuteResults = data.frame("Method" = rep("Gap-com-permute", Simrounds), GapPermuteResults)

GapERResults = data.frame("Method" = rep("Gap-com-ER", Simrounds), GapERResults)

StARSResults = data.frame("Method" = rep("StARS", Simrounds), StARSResults)

PCResults = data.frame("Method" = rep("PC", Simrounds), PCResults)

AGNESResults = data.frame("Method" = rep("AGNES", Simrounds), AGNESResults)

BestResults = data.frame("Method" = rep("Oracle", Simrounds), BestResults)

MergedResults = rbind(GapPermuteResults, GapERResults, StARSResults, PCResults, AGNESResults, BestResults)

#####################################################

GapPermuteResultsARI = data.frame("Method" = rep("Gap-com-permute", Simrounds), "ARI" = ARIResultsGapPermute)

GapERResultsARI = data.frame("Method" = rep("Gap-com-ER", Simrounds), "ARI" = ARIResultsGapER)

StARSResultsARI = data.frame("Method" = rep("StARS", Simrounds), "ARI" = ARIResultsStARS)

PCResultsARI = data.frame("Method" = rep("PC", Simrounds), "ARI" = ARIResultsPC)

AGNESResultsARI = data.frame("Method" = rep("AGNES", Simrounds), "ARI" = ARIResultsAGNES)

MergedResultsARI = rbind(GapPermuteResultsARI, GapERResultsARI, StARSResultsARI, PCResultsARI, AGNESResultsARI)

#####################################################

GapPermuteResultsNMI = data.frame("Method" = rep("Gap-com-permute", Simrounds), "NMI" = NMIResultsGapPermute)

GapERResultsNMI = data.frame("Method" = rep("Gap-com-ER", Simrounds), "NMI" = NMIResultsGapER)

StARSResultsNMI = data.frame("Method" = rep("StARS", Simrounds), "NMI" = NMIResultsStARS)

PCResultsNMI = data.frame("Method" = rep("PC", Simrounds), "NMI" = NMIResultsPC)

AGNESResultsNMI = data.frame("Method" = rep("AGNES", Simrounds), "NMI" = NMIResultsAGNES)

MergedResultsNMI = rbind(GapPermuteResultsNMI, GapERResultsNMI, StARSResultsNMI, PCResultsNMI, AGNESResultsNMI)

#####################################################

GapPermuteResultslambda = data.frame("Method" = rep("Gap-com-permute", Simrounds), "lambda" = lambda_GapPermute)

GapERResultslambda = data.frame("Method" = rep("Gap-com-ER", Simrounds), "lambda" = lambda_GapER)

StARSResultslambda = data.frame("Method" = rep("StARS", Simrounds), "lambda" = lambda_StARS)

PCResultslambda = data.frame("Method" = rep("PC", Simrounds), "lambda" = lambda_PC)

AGNESResultslambda = data.frame("Method" = rep("AGNES", Simrounds), "lambda" = lambda_AGNES)

MergedResultslambda = rbind(GapPermuteResultslambda, GapERResultslambda, StARSResultslambda, PCResultslambda, AGNESResultslambda)

#####################################################

GapPermuteResults_nmb_of_clusters = data.frame("Method" = rep("Gap-com-permute", Simrounds), 
                                               "nmb.of.clusters" = Nmb_of_clusters_GapPermute)

GapERResults_nmb_of_clusters = data.frame("Method" = rep("Gap-com-ER", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_GapER)

StARSResults_nmb_of_clusters = data.frame("Method" = rep("StARS", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_StARS)

PCResults_nmb_of_clusters = data.frame("Method" = rep("PC", Simrounds), 
                                       "nmb.of.clusters" = Nmb_of_clusters_PC)

AGNESResults_nmb_of_clusters = data.frame("Method" = rep("AGNES", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_AGNES)

MergedResults_nmb_of_clusters = rbind(GapPermuteResults_nmb_of_clusters, 
                                      GapERResults_nmb_of_clusters, 
                                      StARSResults_nmb_of_clusters, 
                                      PCResults_nmb_of_clusters, 
                                      AGNESResults_nmb_of_clusters)

#####################################################

GapPermuteResults_nmb_of_clusters_clean = data.frame("Method" = rep("Gap-com-permute", Simrounds), 
                                               "nmb.of.clusters" = Nmb_of_clusters_nonzero_GapPermute)

GapERResults_nmb_of_clusters_clean = data.frame("Method" = rep("Gap-com-ER", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_nonzero_GapER)

StARSResults_nmb_of_clusters_clean = data.frame("Method" = rep("StARS", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_nonzero_StARS)

PCResults_nmb_of_clusters_clean = data.frame("Method" = rep("PC", Simrounds), 
                                       "nmb.of.clusters" = Nmb_of_clusters_nonzero_PC)

AGNESResults_nmb_of_clusters_clean = data.frame("Method" = rep("AGNES", Simrounds), 
                                          "nmb.of.clusters" = Nmb_of_clusters_nonzero_AGNES)

MergedResults_nmb_of_clusters_clean = rbind(GapPermuteResults_nmb_of_clusters_clean, 
                                            GapERResults_nmb_of_clusters_clean, 
                                            StARSResults_nmb_of_clusters_clean, 
                                            PCResults_nmb_of_clusters_clean, 
                                            AGNESResults_nmb_of_clusters_clean)

#####################################################

GapPermuteResults_modularity = data.frame("Method" = rep("Gap-com-permute", Simrounds), 
                                               "modularity" = modularity_GapPermute)

GapERResults_modularity = data.frame("Method" = rep("Gap-com-ER", Simrounds), 
                                          "modularity" = modularity_GapER)

StARSResults_modularity = data.frame("Method" = rep("StARS", Simrounds), 
                                          "modularity" = modularity_StARS)

PCResults_modularity = data.frame("Method" = rep("PC", Simrounds), 
                                       "modularity" = modularity_PC)

AGNESResults_modularity = data.frame("Method" = rep("AGNES", Simrounds), 
                                          "modularity" = modularity_AGNES)

MergedResults_modularity = rbind(GapPermuteResults_modularity, 
                                 GapERResults_modularity, 
                                 StARSResults_modularity, 
                                 PCResults_modularity, 
                                 AGNESResults_modularity)

#####################################################

write.table(MergedResults, 
            paste("Results/Classification_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""), 
            quote = F)

write.table(MergedResultsARI, 
            paste("Results/ARI_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""), 
            quote = F)

write.table(MergedResultsNMI,
            paste("Results/NMI_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(MergedResultslambda, 
            paste("Results/lambda_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(MergedResults_nmb_of_clusters, 
            paste("Results/nmb_of_clusters_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(MergedResults_nmb_of_clusters_clean, 
            paste("Results/nmb_of_clusters_nonzero_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)

write.table(MergedResults_modularity, 
            paste("Results/modularity_", NetMethod, "_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""),
            quote = F)
